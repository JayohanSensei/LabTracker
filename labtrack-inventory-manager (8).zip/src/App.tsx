
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { InventoryExplorer } from './components/InventoryExplorer';
import { BorrowingManager } from './components/BorrowingManager';
import { BreakageReport } from './components/BreakageReport';
import { MissingReport } from './components/MissingReport';
import { AppProvider } from './contexts/AppContext';
import { useAuth } from './contexts/AuthContext'; // AuthProvider is already in index.tsx
import { LoginPage } from './components/auth/LoginPage';
import { UserBorrowPage } from './components/UserBorrowPage';
import { LoginHistoryPage } from './components/admin/LoginHistoryPage';
import { AILabAssistant } from './components/AILabAssistant'; // Import the new component

// Route Protection Components
const UserRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const { currentUser, isLoading } = useAuth();
  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><p className="text-slate-700">Loading...</p></div>; 
  }
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const AdminRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const { currentUser, isLoading } = useAuth();
   if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><p className="text-slate-700">Loading...</p></div>; 
  }
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  if (currentUser.role !== 'admin') {
    return <Navigate to="/inventory" replace />; 
  }
  return children;
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/*"
            element={
              <UserRoute>
                <Layout>
                  <Routes>
                    <Route path="/" element={
                      <NavigateToRoleSpecificDashboard />
                    } />
                    <Route path="/inventory" element={<InventoryExplorer />} />
                    <Route path="/borrow-equipment" element={<UserBorrowPage />} />
                    <Route path="/ai-assistant" element={<AILabAssistant />} /> {/* New Route */}
                    
                    {/* Admin Specific Routes */}
                    <Route path="/dashboard" element={
                      <AdminRoute><Dashboard /></AdminRoute>
                    } />
                    <Route path="/borrowing" element={
                      <AdminRoute><BorrowingManager /></AdminRoute>
                    } />
                    <Route path="/breakage" element={
                      <AdminRoute><BreakageReport /></AdminRoute>
                    } />
                    <Route path="/missing" element={
                      <AdminRoute><MissingReport /></AdminRoute>
                    } />
                     <Route path="/login-history" element={ 
                      <AdminRoute><LoginHistoryPage /></AdminRoute>
                    } />
                    
                    <Route path="*" element={<NavigateToRoleSpecificDashboard />} /> 
                  </Routes>
                </Layout>
              </UserRoute>
            }
          />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
};

const NavigateToRoleSpecificDashboard: React.FC = () => {
  const { currentUser } = useAuth(); 
  if (currentUser?.role === 'admin') {
    return <Navigate to="/dashboard" replace />;
  }
  return <Navigate to="/inventory" replace />;
};


export default App;
