

import React from 'react';
import { InventoryItem, UserRole } from '../types';
import { Card } from './common/Card';
import { Button } from './common/Button';
import { useAuth } from '../contexts/AuthContext';

// Helper for status text styling
const StatusQuantity: React.FC<{ label: string; quantity: number; colorClass?: string }> = ({ label, quantity, colorClass = 'text-slate-700/70' }) => {
  if (quantity <= 0) return null;
  return (
    <p className={`text-xs ${colorClass}`}>
      {label}: <span className="font-semibold">{quantity}</span>
    </p>
  );
};

export interface InventoryItemCardProps {
  item: InventoryItem;
  onViewDetails: (item: InventoryItem) => void;
}

export const InventoryItemCard: React.FC<InventoryItemCardProps> = ({ item, onViewDetails }) => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const totalCurrentStock = item.quantityAvailable + item.quantityBorrowed + item.quantityBroken + item.quantityMissing + item.quantityMaintenance;

  return (
    <Card className="flex flex-col h-full hover:shadow-xl transition-shadow duration-200">
      <img src={item.imageUrl} alt={item.name} className="w-full h-40 object-cover" />
      <div className="p-4 flex-grow flex flex-col">
        <h3 className="text-lg font-semibold text-slate-800/70 mb-1 truncate" title={item.name}>{item.name}</h3>
        <p className="text-sm text-slate-500/70 mb-2">{item.category}</p>
        
        <div className="text-sm mb-3 space-y-0.5">
          <p className="text-slate-600/70">
            Available: <span className="font-bold text-green-600">{item.quantityAvailable}</span>
          </p>
          <StatusQuantity label="Borrowed" quantity={item.quantityBorrowed} colorClass="text-yellow-600/90" />
          <StatusQuantity label="Broken" quantity={item.quantityBroken} colorClass="text-red-600/90" />
          <StatusQuantity label="Missing" quantity={item.quantityMissing} colorClass="text-orange-600/90" />
          <StatusQuantity label="Maintenance" quantity={item.quantityMaintenance} colorClass="text-blue-600/90" />
        </div>

        <p className="text-xs text-slate-500/70 mb-3 flex-grow truncate-2-lines" title={item.description}>
          {item.description}
        </p>
        <p className="text-xs text-slate-400/70 mb-1">Total in system: {totalCurrentStock}</p>
        
        {isAdmin && (
          <Button onClick={() => onViewDetails(item)} variant="secondary" size="sm" className="w-full mt-auto">
            View Details / Edit
          </Button>
        )}
        {!isAdmin && (
             <div className="mt-auto h-[30px]"> {/* Placeholder to maintain card height consistency */} </div>
        )}
      </div>
    </Card>
  );
};
