

import React, { useState, useEffect } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { useAuth } from '../contexts/AuthContext';
import { BorrowerRole } from '../types';
import { Button } from './common/Button';
import { Input } from './common/Input';
import { Select } from './common/Select';
import { BORROWER_ROLES } from '../constants';

interface BorrowingFormProps {
  onFormSubmit?: () => void; // Optional: callback after submission
}

export const BorrowingForm: React.FC<BorrowingFormProps> = ({ onFormSubmit }) => {
  const { inventory, addBorrowerRecord, getInstrumentById } = useAppContext();
  const { currentUser } = useAuth();
  
  const [borrowerName, setBorrowerName] = useState('');
  const [borrowerRole, setBorrowerRole] = useState<BorrowerRole>(BorrowerRole.STUDENT);
  const [gradeLevel, setGradeLevel] = useState('');
  const [instrumentId, setInstrumentId] = useState('');
  const [quantityBorrowed, setQuantityBorrowed] = useState(1);
  const [dateBorrowed, setDateBorrowed] = useState(new Date().toISOString().split('T')[0]); // Today's date
  const [dateDue, setDateDue] = useState('');
  const [notes, setNotes] = useState('');

  const [formError, setFormError] = useState('');

  useEffect(() => {
    if (currentUser) {
      setBorrowerName(currentUser.email); // Use email as name for now
      // Set a default role if desired, or let user select if they can be student/faculty
      // For simplicity, if a logged-in user is borrowing, we might assume a 'USER' role type
      // or map their app role to a BorrowerRole.
      // For now, let them select, but name is fixed.
    }
  }, [currentUser]);


  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!borrowerName || !instrumentId || quantityBorrowed <= 0) {
      setFormError('Please fill in all required fields: Borrower Name, Instrument, and Quantity.');
      return;
    }

    const selectedInstrument = getInstrumentById(instrumentId);
    if (!selectedInstrument) {
      setFormError('Selected instrument not found.');
      return;
    }
    if (selectedInstrument.quantityAvailable < quantityBorrowed) {
      setFormError(`Not enough stock for ${selectedInstrument.name}. Available: ${selectedInstrument.quantityAvailable}`);
      return;
    }
    
    try {
        addBorrowerRecord({
            borrowerName,
            borrowerRole,
            borrowerId: currentUser?.id, // Link to current user ID
            gradeLevel: borrowerRole === BorrowerRole.STUDENT ? gradeLevel : undefined,
            instrumentId,
            quantityBorrowed,
            dateBorrowed,
            dateDue: dateDue || undefined,
            notes: notes || undefined,
        });

        // Reset form (partially, keep name if logged in)
        if (!currentUser) setBorrowerName('');
        setBorrowerRole(BorrowerRole.STUDENT); // Or a default based on user
        setGradeLevel('');
        setInstrumentId('');
        setQuantityBorrowed(1);
        setDateBorrowed(new Date().toISOString().split('T')[0]);
        setDateDue('');
        setNotes('');
        
        if (onFormSubmit) onFormSubmit();

    } catch (error: any) {
        setFormError(error.message || "An unexpected error occurred.");
    }
  };
  
  const availableInventoryItemsForBorrowing = inventory.filter(item => item.quantityAvailable > 0);

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-6 bg-white shadow-md rounded-lg">
      <h2 className="text-xl font-semibold text-slate-700/70 mb-4">Record New Borrowing</h2>
      {formError && <p className="text-red-500/70 bg-red-100 p-3 rounded-md mb-4">{formError}</p>}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input 
            label="Borrower Name*" 
            name="borrowerName" 
            value={borrowerName} 
            onChange={(e) => !currentUser && setBorrowerName(e.target.value)} 
            required 
            readOnly={!!currentUser} 
            className={currentUser ? 'bg-slate-100' : ''}
        />
        <Select
          label="Role*"
          name="borrowerRole"
          value={borrowerRole}
          onChange={(e) => setBorrowerRole(e.target.value as BorrowerRole)}
          options={BORROWER_ROLES.map(role => ({ value: role, label: role }))}
          required
        />
      </div>
      {borrowerRole === BorrowerRole.STUDENT && (
        <Input label="Grade Level / Course & Year" name="gradeLevel" value={gradeLevel} onChange={(e) => setGradeLevel(e.target.value)} />
      )}
      <Select
        label="Instrument to Borrow*"
        name="instrumentId"
        value={instrumentId}
        onChange={(e) => setInstrumentId(e.target.value)}
        options={availableInventoryItemsForBorrowing.map(item => ({ value: item.id, label: `${item.name} (Available: ${item.quantityAvailable})` }))}
        placeholder="Select an instrument"
        required
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Input type="number" label="Quantity*" name="quantityBorrowed" value={quantityBorrowed.toString()} onChange={(e) => setQuantityBorrowed(parseInt(e.target.value) || 1)} min="1" required />
        <Input type="date" label="Date Borrowed*" name="dateBorrowed" value={dateBorrowed} onChange={(e) => setDateBorrowed(e.target.value)} required />
        <Input type="date" label="Date Due (Optional)" name="dateDue" value={dateDue} onChange={(e) => setDateDue(e.target.value)} />
      </div>
       <Input label="Notes (Optional)" name="notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
      <Button type="submit" variant="primary" className="w-full md:w-auto">Add Borrowing Record</Button>
    </form>
  );
};
