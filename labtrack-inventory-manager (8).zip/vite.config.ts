import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  // Load env variables from .env files and system environment
  // Ensure that .env files are in the root of your project.
  const env = loadEnv(mode, (process as any).cwd(), '');

  return {
    plugins: [react()],
    define: {
      // This makes process.env.API_KEY available in your client-side code.
      // Vite will replace it with the actual value of env.API_KEY during the build.
      'process.env.API_KEY': JSON.stringify(env.API_KEY),
    },
    // If your index.html is in the root, and src files are in src/ (default for this setup)
    // Vite defaults are usually fine.
    // build: {
    //   outDir: 'dist',
    // },
    // publicDir: 'public' // This is the default
  };
});