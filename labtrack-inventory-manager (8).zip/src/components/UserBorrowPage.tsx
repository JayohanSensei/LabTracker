
import React from 'react';
import { BorrowingForm } from './BorrowingForm';
import { Card } from './common/Card';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';

export const UserBorrowPage: React.FC = () => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    // This page should be protected by UserRoute, so currentUser should exist.
    // However, as a fallback:
    return (
        <div className="text-center p-8 max-w-3xl mx-auto">
            <Card>
                <p className="text-xl text-slate-700/70">Please log in to borrow equipment.</p>
                <Link to="/login" className="text-blue-600 hover:underline mt-4 inline-block">Go to Login</Link>
            </Card>
        </div>
    );
  }
  
  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <header className="p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">Borrow Laboratory Equipment</h1>
        <p className="text-sm text-slate-600/70">Fill out the form below to request an item from the laboratory.</p>
      </header>
      <BorrowingForm 
        onFormSubmit={() => {
          // Optionally, add a success message or navigation
          alert('Borrowing record submitted successfully!');
        }}
      />
    </div>
  );
};
