
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthContextType, UserRole, LoginAttempt } from '../types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// IMPORTANT: Storing passwords directly in localStorage is insecure and for demo purposes ONLY.
// In a real application, use proper authentication with a backend and secure password hashing.
const ADMIN_EMAIL = 'admin@labtrack.com';
const ADMIN_PASSWORD = 'LabTrackAyohan123'; // Updated Demo password

const USERS_STORAGE_KEY = 'labtrack_users';
const CURRENT_USER_STORAGE_KEY = 'labtrack_current_user';
const LOGIN_HISTORY_STORAGE_KEY = 'labtrack_login_history';

const getStoredUsers = (): User[] => {
  const storedUsers = localStorage.getItem(USERS_STORAGE_KEY);
  let users: User[] = storedUsers ? JSON.parse(storedUsers) : [];
  // Ensure admin user exists with the current password
  const adminUserIndex = users.findIndex(u => u.email === ADMIN_EMAIL);
  if (adminUserIndex !== -1) {
    // If admin exists, ensure password is up to date (for demo purposes)
    // In a real app, password changes are handled differently.
    if (users[adminUserIndex].password !== ADMIN_PASSWORD) {
        users[adminUserIndex].password = ADMIN_PASSWORD;
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    }
  } else {
    users.push({ id: 'admin-001', email: ADMIN_EMAIL, password: ADMIN_PASSWORD, role: 'admin' });
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }
  return users;
};

const getStoredCurrentUser = (): User | null => {
  const storedUser = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
  return storedUser ? JSON.parse(storedUser) : null;
};

const getStoredLoginHistory = (): LoginAttempt[] => {
  const storedHistory = localStorage.getItem(LOGIN_HISTORY_STORAGE_KEY);
  return storedHistory ? JSON.parse(storedHistory) : [];
}

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(getStoredCurrentUser());
  const [isLoading, setIsLoading] = useState(true);
  const [loginHistory, setLoginHistory] = useState<LoginAttempt[]>(getStoredLoginHistory());

  useEffect(() => {
    // This effect ensures we check local storage once on mount
    // and initialize admin user correctly.
    getStoredUsers(); // Ensures admin user is initialized/updated if needed
    const user = getStoredCurrentUser();
    if (user) {
      setCurrentUser(user);
    }
    setLoginHistory(getStoredLoginHistory()); // Load history on mount
    setIsLoading(false);
  }, []);

  useEffect(() => {
    // Persist current user to localStorage
    if (currentUser) {
      localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(CURRENT_USER_STORAGE_KEY);
    }
  }, [currentUser]);

  useEffect(() => {
    // Persist login history to localStorage
    localStorage.setItem(LOGIN_HISTORY_STORAGE_KEY, JSON.stringify(loginHistory));
  }, [loginHistory]);

  const logLoginAttempt = (email: string, success: boolean) => {
    const newAttempt: LoginAttempt = {
      id: `login-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      email,
      timestamp: new Date().toISOString(),
      success,
    };
    setLoginHistory(prevHistory => [newAttempt, ...prevHistory]); // Add to start of array
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    const users = getStoredUsers(); // Ensures admin has correct password
    const user = users.find(u => u.email === email && u.password === password); // Plain text check for demo
    
    const successfulLogin = !!user;
    logLoginAttempt(email, successfulLogin);

    if (successfulLogin) {
      setCurrentUser(user);
      setIsLoading(false);
      return true;
    }
    setCurrentUser(null);
    setIsLoading(false);
    return false;
  };

  const signup = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    let users = getStoredUsers();
    if (users.find(u => u.email === email)) {
      setIsLoading(false);
      // Not logging signup attempts in login history, could be a separate audit if needed
      return false; // User already exists
    }
    const newUser: User = {
      id: `user-${Date.now()}`,
      email,
      password, // Storing plain for demo
      role: 'user',
    };
    users.push(newUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    setCurrentUser(newUser);
    // Log successful signup as a successful "login" for consistency if desired, or handle separately.
    // For simplicity, we are not logging signups to loginHistory here.
    setIsLoading(false);
    return true;
  };

  const logout = () => {
    // Optionally log logout events if needed
    setCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ currentUser, isLoading, login, signup, logout, loginHistory }}>
      {!isLoading && children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
