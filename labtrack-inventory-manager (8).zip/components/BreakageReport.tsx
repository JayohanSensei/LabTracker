
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { InventoryItem, BorrowerRecord, ReturnRemark } from '../types';
import { Card } from './common/Card';

interface CombinedBrokenItem {
  id: string; 
  name: string;
  type: 'Inventory' | 'Borrowing';
  dateReported: string; 
  reportedBy?: string; 
  quantity: number;
  details?: string; 
  category?: string; 
}

export const BreakageReport: React.FC = () => {
  const { inventory, borrowers } = useAppContext();

  const brokenItemsFromInventory: CombinedBrokenItem[] = inventory
    .filter(item => item.quantityBroken > 0)
    .map(item => ({
      id: item.id,
      name: item.name,
      type: 'Inventory' as const,
      dateReported: 'N/A (Inventory Status)', // Or a last updated timestamp if available
      reportedBy: 'System (Inventory Audit)',
      quantity: item.quantityBroken, 
      details: item.notes || `Marked as ${item.quantityBroken} broken in inventory.`,
      category: item.category,
    }));

  const brokenItemsFromBorrowing: CombinedBrokenItem[] = borrowers
    .filter(record => record.status === 'Returned' && record.remarks === ReturnRemark.BROKEN)
    .map(record => ({
      id: record.id, // This is borrower record ID
      name: record.instrumentName,
      type: 'Borrowing' as const,
      dateReported: record.dateReturned || 'N/A',
      reportedBy: record.borrowerName,
      quantity: record.quantityBorrowed, // The quantity from this specific borrowing transaction
      details: record.notes || `Returned broken by ${record.borrowerName}.`,
      category: inventory.find(i => i.id === record.instrumentId)?.category
    }));
  
  const allBrokenItems = [...brokenItemsFromInventory, ...brokenItemsFromBorrowing].sort((a,b) => {
    // Handle 'N/A' dates by pushing them to the end or beginning
    if (a.dateReported.includes('N/A') && !b.dateReported.includes('N/A')) return 1;
    if (!a.dateReported.includes('N/A') && b.dateReported.includes('N/A')) return -1;
    if (a.dateReported.includes('N/A') && b.dateReported.includes('N/A')) return 0;
    return new Date(b.dateReported).getTime() - new Date(a.dateReported).getTime();
  });


  return (
    <div className="space-y-6">
      <header className="p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">Breakage Report</h1>
        <p className="text-sm text-slate-600/70">Summary of all reported broken laboratory equipment from inventory and borrowing records.</p>
      </header>

      {allBrokenItems.length > 0 ? (
        <div className="space-y-4">
          {allBrokenItems.map((item) => (
            <Card key={`${item.type}-${item.id}`} className="border-l-4 border-red-500">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                <div>
                  <h3 className="text-lg font-semibold text-red-700/70">{item.name}</h3>
                  <p className="text-sm text-slate-500/70">Category: {item.category || 'N/A'}</p>
                   <p className="text-sm text-slate-500/70">Source: {item.type === 'Inventory' ? 'Inventory Record' : 'Borrowing Return'}</p>
                </div>
                <div className="text-sm text-slate-700/70">
                  <p><span className="font-medium">Quantity Affected:</span> {item.quantity}</p>
                  <p><span className="font-medium">Date Reported/Returned:</span> {item.dateReported}</p>
                  {item.reportedBy && <p><span className="font-medium">Identified By:</span> {item.reportedBy}</p>}
                </div>
                <div className="md:col-span-1">
                   <p className="text-sm font-medium text-slate-700/70">Details:</p>
                   <p className="text-sm text-slate-600/70 bg-slate-50 p-2 rounded break-words">{item.details || 'No specific details provided.'}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <div className="text-center py-10">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-green-500 mb-4" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-slate-600/70 text-xl">No broken items reported.</p>
            <p className="text-slate-500/70">All equipment is currently in good standing or not reported as broken.</p>
          </div>
        </Card>
      )}
    </div>
  );
};
