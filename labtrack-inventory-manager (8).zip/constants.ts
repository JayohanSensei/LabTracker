
import { InventoryItem, LabCategory, ItemStatus, BorrowerRecord, BorrowerRole, BorrowingStatus, ReturnRemark } from './types';

// Helper function for consistent image URLs
const getImageUrl = (name: string, width: number = 200, height: number = 150): string => {
  const seed = name.toLowerCase().replace(/[^a-z0-9\s]+/g, '').replace(/\s+/g, '-');
  return `https://picsum.photos/seed/${seed}/${width}/${height}`;
};

const BIOLOGY_INSTRUMENTS = [
  "Administrative Globe", "Anemometer", "Aneroid Barometer", "Bandage Scissors", "Basin (Aluminum)",
  "Blocks Of Wood 2x2x3", "Blocks Of Wood 2x3x3", "Brain Model", "Circulatory System Model", "Desk Lamp (Black)",
  "Digestive System Model", "Dissecting Blade Holder", "Dissecting Forceps", "Dissecting Knife", "Dissecting Pan",
  "Dissecting Probe (Needle Straight Point)", "Dissecting Spatula", "Dissecting Scissors", "DNA Model", "Ear Model",
  "Eye Model", "Flower Model", "Heart Model", "Human Torso Headless Model", "Human Torso Model With Head",
  "Microscope (Compound)", "Microscope (Digital) W/ Computer Set", "Microscope (Electronic)",
  "Microscope (Electronic-Wide-base)", "Mirror", "Mouth Model", "Meiosis Model", "Mitosis Model",
  "Prepared Slides (Botany)", "Prepared Slides (Histology)", "Prepared Slides (Zoology)", "Rain Gauge (China)",
  "Rocks Set (20 Pcs.)", "Rocks Set (50 Pcs. – Brown)", "Rocks Set (Native-Small)", "Skeletal System Model",
  "Skin Model", "Urinary System Model", "Wind Vane"
];

const CHEMISTRY_INSTRUMENTS_VARIATIONS: { name: string, types: string[], baseDesc?: string, baseSetup?: string }[] = [
  { name: "Alcohol Lamp", types: ["Big", "Small"], baseDesc: "Produces an open flame for heating in laboratory experiments.", baseSetup: "Used with a wick and alcohol fuel. Ensure proper ventilation." },
  { name: "Beaker China", types: ["50 ml", "100 ml", "400 ml", "500 ml"], baseDesc: "Ceramic beaker for mixing, stirring, and heating chemicals, resistant to thermal shock.", baseSetup: "Can be heated directly. Use with stirring rods." },
  { name: "Beaker Pyrex", types: ["100 ml", "150 ml", "250 ml", "400 ml", "500 ml", "600 ml"], baseDesc: "Glass beaker made of borosilicate glass, used for mixing, stirring, and heating liquids.", baseSetup: "Suitable for use on hot plates or with Bunsen burners (with wire gauze)." },
  { name: "Bunsen Burner", types: ["Black", "Blue", "Red"], baseDesc: "Gas burner producing a single open flame, used for heating, sterilization, and combustion.", baseSetup: "Requires gas source and tubing. Adjust air intake for optimal flame." },
  { name: "Burette", types: ["Acid", "Base"], baseDesc: "Graduated glass tube with a tap at one end, for dispensing known amounts of a liquid reagent in titrations.", baseSetup: "Clamped vertically to a stand. Read volume at the meniscus." },
  { name: "Crucible Tong", types: ["With Rubber", "Without Rubber"], baseDesc: "Used to hold hot crucibles and other heated objects.", baseSetup: "Rubber-tipped tongs offer better grip for cooler items." },
  { name: "Distilling Flask", types: ["500 ml"], baseDesc: "Used for distillation processes to separate mixtures based on differences in boiling points.", baseSetup: "Connected to a condenser and receiving flask. Heat source applied to the flask." },
  { name: "Erlenmeyer Flask", types: ["50 ml", "125 ml", "250 ml", "500 ml"], baseDesc: "Conical flask with a flat bottom and cylindrical neck, used for mixing, storing, and heating chemicals, reduces spillage.", baseSetup: "Can be swirled manually or with a magnetic stirrer." },
  { name: "Evaporating Dish", types: ["50 ml -Glass", "50 ml -Porcelain", "75 ml", "100 ml"], baseDesc: "Shallow, open dish used to evaporate solvents from a solution to concentrate it or obtain a solid residue.", baseSetup: "Heated gently over a Bunsen burner or on a hot plate." },
  { name: "Florence Flask", types: ["125 ml", "250 ml"], baseDesc: "Round-bottom flask with a long neck, used for uniform heating, boiling, distillation and ease of swirling.", baseSetup: "Often supported by a ring clamp or placed on a cork ring." },
  { name: "Glass Funnel", types: ["60 mm", "75 mm"], baseDesc: "Used to channel liquids or fine-grained substances into containers with a small opening.", baseSetup: "May be used with filter paper for separations." },
  { name: "Graduated Cylinder", types: ["10 ml", "25 ml", "50 ml", "100 ml", "250 ml", "500 ml"], baseDesc: "Tall cylindrical container with volume markings, used for measuring the volume of liquids accurately.", baseSetup: "Place on a level surface and read the meniscus at eye level." },
  { name: "Hot Plate", types: ["Orange-Cimarec 2", "La Germania", "Suteki", "White-American Heritage"], baseDesc: "Electric device used for heating glassware or its contents.", baseSetup: "Place glassware directly on the surface. Some models include magnetic stirrers." },
  { name: "Hydrometer", types: ["Heavy", "Heavy W/ Bulb", "Light", "Specific Gravity"], baseDesc: "Instrument used for measuring the relative density of liquids based on the concept of buoyancy.", baseSetup: "Floated in the liquid to be tested; reading taken at the liquid surface." },
  { name: "Measuring Cup", types: ["Plastic White-set", "Plastic White-solo"], baseDesc: "Used for approximate measurements of liquid volumes.", baseSetup: "Suitable for general purpose measurements where high accuracy is not critical." },
  { name: "Measuring Pipette", types: ["1 ml", "5 ml", "10 ml"], baseDesc: "Graduated pipette used to measure and transfer variable volumes of liquid.", baseSetup: "Used with a pipette filler. Volume is read from graduations." },
  { name: "Measuring Spoons", types: ["Plastic White-set"], baseDesc: "Set of spoons for measuring small, approximate volumes of solids or liquids.", baseSetup: "Used for scooping and transferring substances." },
  { name: "Mortar And Pestle", types: ["Big", "Regular"], baseDesc: "Used to crush, grind, and mix solid substances.", baseSetup: "Substance is placed in the mortar and ground with the pestle." },
  { name: "Picnometer", types: ["50 ml"], baseDesc: "A flask with a close-fitting ground glass stopper with a fine bore through its centre, used for measuring the density of a liquid.", baseSetup: "Filled precisely to a known volume." },
  { name: "Reagent Bottle", types: ["Amber", "Clear-Narrow Mouth", "Clear- Wide Mouth"], baseDesc: "Bottles used to store chemicals in liquid or powder form.", baseSetup: "Amber bottles protect light-sensitive chemicals. Wide mouth for solids, narrow for liquids." },
  { name: "Spatula", types: ["Flat Aluminum, Big", "Flat Aluminum, Small", "Porcelain", "Spoon – Like Metal"], baseDesc: "Used for scraping, transferring, or applying powders and paste-like chemicals or treatments.", baseSetup: "Choose material based on chemical compatibility." },
  { name: "Thermometer Alcohol", types: ["10 -110°C"], baseDesc: "Measures temperature using alcohol as the thermometric liquid.", baseSetup: "Immerse bulb in the substance to be measured. Avoid direct heating of the bulb." },
  { name: "Volumetric Flask", types: ["25 ml", "250 ml"], baseDesc: "Calibrated to contain a precise volume at a particular temperature, used for preparing solutions of known concentration.", baseSetup: "Filled until the liquid's meniscus aligns with the calibration mark." },
  { name: "Volumetric Pipette", types: ["5 ml", "10 ml", "50 ml"], baseDesc: "Calibrated to deliver a precise volume of liquid.", baseSetup: "Used with a pipette filler. Delivers a fixed volume." }
];

const CHEMISTRY_INSTRUMENTS_SINGLE = [
  "Aluminum Rod Solid", "Analytical Balance (Industrial Balance Model)", "Atomic Model", "Bell", "Condenser",
  "Conductivity Apparatus", "Copper Rod Solid", "Crucible With Cover", "Double Beam Balance",
  "Electric Stove (National)", "Electrolysis Apparatus", "Electroscope Apparatus (Flask)", "Flame Spreader",
  "Fumehood", "Glass File (Triangular File)", "J - Tube Apparatus", "Kettle", "Molecular Orbital Model",
  "Periodic Table Poster", "Petri Dish", "pH Meter Pen-type", "Platform Balance", "Plastic Rod (Insulator)",
  "Safety Goggles (Plastic)", "Separatory Funnel", "Steel Rod Solid", "Stirring Rod", "Test Tube Holder",
  "Test Tube Rack", "Thistle Tube", "Triple Beam Balance", "Tripod", "Watch Glass", "Wooden Rod (Insulator)"
];


const PHYSICS_INSTRUMENTS_VARIATIONS: { name: string, types: string[], baseDesc?: string, baseSetup?: string }[] = [
  { name: "Ammeter", types: ["5A"], baseDesc: "Measures electric current in amperes.", baseSetup: "Connected in series within a circuit." },
  { name: "Blocks", types: ["Copper", "Iron"], baseDesc: "Solid blocks of specified material, used in experiments involving density, heat capacity, or friction.", baseSetup: "Used with balances, calorimeters, or inclined planes." },
  { name: "Board Protractor", types: ["CintraBoard", "Orange Plastic"], baseDesc: "Large protractor for use on whiteboards or large surfaces to measure angles.", baseSetup: "Used in geometry demonstrations or large-scale physics drawings." },
  { name: "Burette Clamp", types: ["Double", "Single"], baseDesc: "Holds burettes, test tubes, or flasks securely to a retort stand.", baseSetup: "Attached to an iron stand." },
  { name: "C - Clamp", types: ["Black", "Red"], baseDesc: "Used to hold objects firmly in place.", baseSetup: "Versatile clamping tool for various setups." },
  { name: "Cork Borer", types: ["Bronze", "Silver"], baseDesc: "Set of metal tubes for cutting holes in corks or rubber stoppers.", baseSetup: "Select appropriate size and twist to cut." },
  { name: "Cylinder Weights", types: ["500g Beige", "1000g Beige", "500g Black", "1000g Black"], baseDesc: "Calibrated cylindrical masses used in experiments involving force, mass, and mechanics.", baseSetup: "Can be hung from spring balances or used on lever arms." },
  { name: "Diffraction Slit", types: ["Double", "Single"], baseDesc: "Slide with precision single or double slits used to demonstrate diffraction and interference of light.", baseSetup: "Used with a laser or monochromatic light source and a screen." },
  { name: "Dynamic Cart", types: ["Steel", "Wooden"], baseDesc: "Low-friction carts used in experiments on motion, forces, and collisions.", baseSetup: "Used on a track or flat surface. Can be loaded with masses." },
  { name: "Hooked Mass", types: ["20g", "250g", "500g"], baseDesc: "Calibrated masses with hooks for easy attachment in experiments.", baseSetup: "Used with spring balances, pulleys, or levers." },
  { name: "Inclined Plane", types: ["With Pulley", "Without Pulley"], baseDesc: "A flat supporting surface tilted at an angle, with one end higher than the other, used for studying forces and motion.", baseSetup: "Objects can be rolled or slid down the plane. Pulleys can be used to apply forces." },
  { name: "Iron Ring", types: ["Solid", "Tin 4'"], baseDesc: "Metal rings that attach to a retort stand, used to support flasks, beakers, or funnels.", baseSetup: "Often used with wire gauze to support glassware over a flame." },
  { name: "Lens", types: ["Concave", "Convex"], baseDesc: "Optical lenses used to converge or diverge light, for experiments in optics.", baseSetup: "Used with light sources and optical benches to study image formation." },
  { name: "Long Stand Rod", types: ["9.5mm X 250mm", "9.5mm X 500mm", "12.7mm X 1000mm"], baseDesc: "Metal rods of various lengths and diameters used with bases to form retort stands.", baseSetup: "Supports clamps and other apparatus." },
  { name: "Magnet", types: ["Bar 4''", "Bar, Big", "Bar, Short", "Horse Shoe", "U - Shaped 3''", "U - Shaped"], baseDesc: "Objects that produce a magnetic field, used to study magnetism and its effects.", baseSetup: "Used with iron filings, compasses, or in electromagnetic experiments." },
  { name: "Magnetic Compass", types: ["Replacement Small", "Silver"], baseDesc: "Device that shows the direction of magnetic north, used to detect and map magnetic fields.", baseSetup: "Keep away from other magnets or ferrous materials for accurate readings." },
  { name: "Magnifying Lens", types: ["Big", "Medium", "Regular", "Small"], baseDesc: "A convex lens used to produce a magnified image of an object.", baseSetup: "Held close to the object being viewed." },
  { name: "Mirror", types: ["Concave X 25mm", "Concave X 75mm", "Convex 25mm", "Convex 75mm"], baseDesc: "Reflective surfaces (concave or convex) used in optics experiments to study image formation by reflection.", baseSetup: "Used with light sources, ray boxes, and optical benches." },
  { name: "Multitester", types: ["Analog Sanwa", "Digital Generic", "Digital Sanwa"], baseDesc: "Measures voltage, current, and resistance in electrical circuits.", baseSetup: "Select correct function and range before connecting to a circuit." },
  { name: "Optical Bench", types: ["College - Type", "White", "Yellow"], baseDesc: "A long, graduated track on which optical components like lenses, mirrors, and light sources can be mounted and moved.", baseSetup: "Used for precise optics experiments." },
  { name: "Pliers", types: ["Insulated Diagonal Cutting 6'' 152mm", "Long Nose 6'' 152 Mm", "Slip Joint"], baseDesc: "Hand tools used for gripping, bending, or cutting wires and small objects.", baseSetup: "Insulated pliers provide safety when working with electrical components." },
  { name: "Prism", types: ["Right Angle", "Triangle"], baseDesc: "A transparent optical element with flat, polished surfaces that refract light. Used to disperse light into its constituent spectral colors.", baseSetup: "Used with a light source to demonstrate dispersion and refraction." },
  { name: "Pulley", types: ["Double", "Single", "Triple"], baseDesc: "Wheels on an axle or shaft that are designed to support movement and change of direction of a taut cable or belt.", baseSetup: "Used in experiments on mechanical advantage, forces, and motion." },
  { name: "Screw Driver", types: ["Flat -", "Phillips+"], baseDesc: "Tool for screwing and unscrewing screws.", baseSetup: "Match screwdriver type and size to the screw head." },
  { name: "Set Of Weights", types: ["500g To 10g Green Box", "500g to 10g Red Box", "500g to 1g Bronze", "Ohaus 50g to 1g"], baseDesc: "Collections of calibrated masses used for precise measurements in various physics experiments.", baseSetup: "Used with balances or for applying known forces." },
  { name: "Slinky", types: ["Coil Metal", "Wire Helix"], baseDesc: "A precompressed helical spring toy used to demonstrate wave properties like longitudinal and transverse waves.", baseSetup: "Can be stretched on a flat surface or held at both ends." },
  { name: "Spring Balance", types: ["10 N", "2 N", "5 N"], baseDesc: "Device that measures weight or force by the opposition of a spring to that force.", baseSetup: "Calibrated in Newtons or grams. Hang objects from the hook." },
  { name: "Triangle Regular", types: ["Wood"], baseDesc: "Wooden triangular shapes, potentially for geometry or simple mechanics.", baseSetup: "Versatile for demonstrations or as components in simple structures." },
  { name: "Tuning Fork", types: ["#256", "#384", "#512", "Set (8 pcs. / Box)"], baseDesc: "A two-pronged fork that vibrates at a specific constant pitch when set vibrating by striking it against a surface.", baseSetup: "Used in sound experiments, e.g., to demonstrate resonance." },
  { name: "Wire With Alligator Clip", types: ["Black", "Red"], baseDesc: "Electrical wires with alligator clips at ends for making temporary electrical connections.", baseSetup: "Used to connect components in circuits. Color-coding (red for positive, black for negative) is common." }
];

const PHYSICS_INSTRUMENTS_SINGLE = [
  "Air Blower, Variable Speed Control", "Archimedes Principle Apparatus", "Ball & Ring Apparatus", "Ball Bearing",
  "Ball-Peen Hammer", "Basic Electronic Kit", "Battery Tester", "Board Compass (Wood)", "Boiler",
  "Boyle's Law Apparatus", "Calorimeter", "Clamp Holder Rightangle (S - Clamp)", "Coefficient Forces Apparatus",
  "Crane Boom Apparatus (Set)", "Electrical Twister (Project Of Student)", "Extension Clamp",
  "Flood Alarm (Project Of Student)", "Force Table Apparatus", "Free Fall Apparatus (Base, Magnetic Coil, Stand)",
  "Friction Board Apparatus", "Galvanometer", "Hooke's Law Apparatus", "Iron Stand", "Laser Pointer",
  "Lead Electrode", "Light Source (For Diffraction Slit)", "Magnetizer", "Meter Stick", "Micrometer Caliper",
  "Momentum Apparatus (Collision Ball)", "Motor Generator Experimental Kit (Dynamo Torch)", "OHP (Project Of Student)",
  "Overflow Can", "Peg Board", "Penlight Metal Case", "Power Supply", "Precision Screw Driver Set",
  "Resistance Box", "Resonance Apparatus Set", "Ripple Tank", "Soldering Iron", "Solenoid", "Sonometer",
  "Spin Dryer Bike (Project of Student)", "Stop Watch (Casio)", "Stripping Knife", "Syringe (Glass)",
  "Ticker Timer", "U - Tube", "Vernier Caliper", "Volt Meter", "Wide Band Signal Generator (Wheeler)",
  "Worn W/ Axle Assembly (Wheel & Axle)"
];


const generateInventoryData = (): InventoryItem[] => {
  const items: InventoryItem[] = [];
  let bioId = 1;
  let chemId = 1;
  let physId = 1;

  const defaultQtyLastYearBio = 5;
  const defaultQtyLastYearChem = 10;
  const defaultQtyLastYearChemSingle = 8;
  const defaultQtyLastYearPhys = 3;
  const defaultQtyLastYearPhysSingle = 2;


  // Biology Items
  BIOLOGY_INSTRUMENTS.forEach(name => {
    items.push({
      id: `bio-${String(bioId++).padStart(3, '0')}`,
      name: name,
      category: LabCategory.BIOLOGY,
      imageUrl: getImageUrl(name),
      description: `A standard laboratory instrument for ${name.toLowerCase()}. Essential for various biological studies, dissections, or observations.`,
      labSetup: "Typically used with specimens, slides, or models. Refer to specific experimental procedures for detailed setup and safety precautions.",
      quantityLastYear: defaultQtyLastYearBio,
      quantityAvailable: defaultQtyLastYearBio,
      quantityBorrowed: 0,
      quantityBroken: 0,
      quantityMissing: 0,
      quantityMaintenance: 0,
    });
  });
   // Specific item for borrower data - placeholder for ID matching
  const microscopeCompound = items.find(item => item.name === "Microscope (Compound)");
  if (microscopeCompound) (microscopeCompound as any).originalIdForBorrower = 'bio-001-placeholder';


  // Chemistry Items with Variations
  CHEMISTRY_INSTRUMENTS_VARIATIONS.forEach(group => {
    group.types.forEach(type => {
      const itemName = `${group.name} (${type})`;
      items.push({
        id: `chem-${String(chemId++).padStart(3, '0')}`,
        name: itemName,
        category: LabCategory.CHEMISTRY,
        imageUrl: getImageUrl(itemName),
        description: group.baseDesc || `A ${type} ${group.name.toLowerCase()} used for various chemical processes, measurements, or reactions.`,
        labSetup: group.baseSetup || "Used in chemistry labs. Follow safety guidelines and experiment-specific setup instructions. Often requires glassware, heating sources, or measuring devices.",
        quantityLastYear: defaultQtyLastYearChem,
        quantityAvailable: defaultQtyLastYearChem,
        quantityBorrowed: 0,
        quantityBroken: 0,
        quantityMissing: 0,
        quantityMaintenance: 0,
      });
      if (itemName === "Beaker Pyrex (250 ml)") (items[items.length-1] as any).originalIdForBorrower = 'chem-001-placeholder';
      if (itemName === "Bunsen Burner (Blue)") (items[items.length-1] as any).originalIdForBorrower = 'chem-002-placeholder';

    });
  });

  // Single Chemistry Items
  CHEMISTRY_INSTRUMENTS_SINGLE.forEach(name => {
    items.push({
      id: `chem-${String(chemId++).padStart(3, '0')}`,
      name: name,
      category: LabCategory.CHEMISTRY,
      imageUrl: getImageUrl(name),
      description: `A standard laboratory instrument, ${name.toLowerCase()}, used in various chemical experiments and analyses.`,
      labSetup: "Setup depends on the specific experiment. Ensure chemical compatibility and adhere to safety protocols. May be used with other chemical apparatus.",
      quantityLastYear: defaultQtyLastYearChemSingle,
      quantityAvailable: defaultQtyLastYearChemSingle,
      quantityBorrowed: 0,
      quantityBroken: 0,
      quantityMissing: 0,
      quantityMaintenance: 0,
    });
  });

  // Physics Items with Variations
  PHYSICS_INSTRUMENTS_VARIATIONS.forEach(group => {
    group.types.forEach(type => {
      const itemName = `${group.name} (${type})`;
      items.push({
        id: `phys-${String(physId++).padStart(3, '0')}`,
        name: itemName,
        category: LabCategory.PHYSICS,
        imageUrl: getImageUrl(itemName),
        description: group.baseDesc || `A ${type} ${group.name.toLowerCase()} used for physics experiments involving mechanics, optics, electricity, or other physical phenomena.`,
        labSetup: group.baseSetup || "Setup varies widely based on the experiment. Often involves circuits, mechanical assemblies, optical arrangements, or data acquisition tools.",
        quantityLastYear: defaultQtyLastYearPhys,
        quantityAvailable: defaultQtyLastYearPhys,
        quantityBorrowed: 0,
        quantityBroken: 0,
        quantityMissing: 0,
        quantityMaintenance: 0,
      });
       if (itemName === "Spring Balance (5 N)") (items[items.length-1] as any).originalIdForBorrowerPhys = 'phys-001-placeholder';
    });
  });

  // Single Physics Items
  PHYSICS_INSTRUMENTS_SINGLE.forEach(name => {
    items.push({
      id: `phys-${String(physId++).padStart(3, '0')}`,
      name: name,
      category: LabCategory.PHYSICS,
      imageUrl: getImageUrl(name),
      description: `A laboratory instrument, ${name.toLowerCase()}, used for conducting physics experiments and demonstrations.`,
      labSetup: "Consult specific experiment guides for setup procedures. May require power sources, measurement devices, or specialized components.",
      quantityLastYear: defaultQtyLastYearPhysSingle,
      quantityAvailable: defaultQtyLastYearPhysSingle,
      quantityBorrowed: 0,
      quantityBroken: 0,
      quantityMissing: 0,
      quantityMaintenance: 0,
    });
     if (name === "Meter Stick") (items[items.length-1] as any).originalIdForBorrowerPhysMeter = 'phys-002-placeholder';
     if (name === "Power Supply") (items[items.length-1] as any).originalIdForBorrowerPhysPower = 'phys-003-placeholder';
  });
  
  // Example items to ensure some specific statuses for demonstration
  const bunsenBurnerBlue = items.find(item => item.name === "Bunsen Burner (Blue)");
  if (bunsenBurnerBlue) {
    const brokenCount = 3;
    bunsenBurnerBlue.quantityBroken = brokenCount;
    bunsenBurnerBlue.quantityAvailable = bunsenBurnerBlue.quantityLastYear - brokenCount > 0 ? bunsenBurnerBlue.quantityLastYear - brokenCount : 0;
    bunsenBurnerBlue.notes = "3 units have clogged nozzles and are marked as broken.";
  }

  const testTubeRack = items.find(item => item.name === "Test Tube Rack");
   if (testTubeRack) {
    const missingCount = 1;
    testTubeRack.quantityMissing = missingCount;
    testTubeRack.quantityAvailable = testTubeRack.quantityLastYear - missingCount > 0 ? testTubeRack.quantityLastYear - missingCount : 0;
    testTubeRack.notes = "1 rack confirmed missing after last audit.";
  }

  const powerSupply = items.find(item => item.name === "Power Supply"); 
  if (powerSupply) {
    const maintenanceCount = 1;
    powerSupply.quantityMaintenance = maintenanceCount;
    powerSupply.quantityAvailable = powerSupply.quantityLastYear - maintenanceCount > 0 ? powerSupply.quantityLastYear - maintenanceCount : 0;
    powerSupply.notes = "1 unit sent for repair.";
  }

  return items;
};

export const INITIAL_INVENTORY_DATA: InventoryItem[] = generateInventoryData();


// Update INITIAL_BORROWER_DATA to use new IDs
const findNewId = (originalPlaceholder: string): string | undefined => {
    const item = INITIAL_INVENTORY_DATA.find(i => (i as any).originalIdForBorrower === originalPlaceholder || (i as any).originalIdForBorrowerPhys === originalPlaceholder || (i as any).originalIdForBorrowerPhysMeter === originalPlaceholder || (i as any).originalIdForBorrowerPhysPower === originalPlaceholder );
    return item?.id;
}

const newBio001Id = findNewId('bio-001-placeholder') || INITIAL_INVENTORY_DATA.find(i => i.name === "Microscope (Compound)")?.id || 'bio-026'; 
const newChem001Id = findNewId('chem-001-placeholder') || INITIAL_INVENTORY_DATA.find(i => i.name === "Beaker Pyrex (250 ml)")?.id || 'chem-009'; 
const newChem002Id = findNewId('chem-002-placeholder') || INITIAL_INVENTORY_DATA.find(i => i.name === "Bunsen Burner (Blue)")?.id || 'chem-011'; 


export const INITIAL_BORROWER_DATA: BorrowerRecord[] = [
  {
    id: 'borrow-001',
    borrowerName: 'Jane Doe',
    borrowerRole: BorrowerRole.STUDENT,
    gradeLevel: 'Grade 11',
    instrumentId: newBio001Id,
    instrumentName: INITIAL_INVENTORY_DATA.find(i=>i.id === newBio001Id)?.name || 'Microscope (Compound)',
    quantityBorrowed: 1,
    dateBorrowed: '2024-05-10',
    dateDue: '2024-05-17',
    status: BorrowingStatus.BORROWED,
  },
  {
    id: 'borrow-002',
    borrowerName: 'Dr. Alan Smith',
    borrowerRole: BorrowerRole.FACULTY,
    instrumentId: newChem001Id,
    instrumentName: INITIAL_INVENTORY_DATA.find(i=>i.id === newChem001Id)?.name || 'Beaker Pyrex (250 ml)',
    quantityBorrowed: 5,
    dateBorrowed: '2024-05-01',
    dateReturned: '2024-05-05',
    status: BorrowingStatus.RETURNED,
    remarks: ReturnRemark.COMPLETE,
  },
    {
    id: 'borrow-003',
    borrowerName: 'Mike Ross',
    borrowerRole: BorrowerRole.STUDENT,
    gradeLevel: 'Grade 10',
    instrumentId: newChem002Id, 
    instrumentName: INITIAL_INVENTORY_DATA.find(i=>i.id === newChem002Id)?.name || 'Bunsen Burner (Blue)',
    quantityBorrowed: 1, // This item (Bunsen Burner (Blue)) has 3 broken. Ensure this borrow is from available stock.
    dateBorrowed: '2024-04-15',
    dateReturned: '2024-04-20',
    status: BorrowingStatus.RETURNED,
    remarks: ReturnRemark.BROKEN,
    notes: 'Nozzle damaged during experiment.'
  }
];


export const LAB_CATEGORIES = Object.values(LabCategory);
export const ITEM_STATUSES = Object.values(ItemStatus); // Still useful for defining status types
export const BORROWER_ROLES = Object.values(BorrowerRole);
export const BORROWING_STATUSES = Object.values(BorrowingStatus);
export const RETURN_REMARKS = Object.values(ReturnRemark);
