
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { InventoryExplorer } from './components/InventoryExplorer';
import { BorrowingManager } from './components/BorrowingManager';
import { BreakageReport } from './components/BreakageReport';
import { MissingReport } from './components/MissingReport';
import { AppProvider } from './contexts/AppContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginPage } from './components/auth/LoginPage';
import { UserBorrowPage } from './components/UserBorrowPage';
import { LoginHistoryPage } from './components/admin/LoginHistoryPage'; // Import new page

// Route Protection Components
const UserRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const { currentUser, isLoading } = useAuth();
  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><p className="text-slate-700">Loading...</p></div>; // Or a spinner
  }
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  return children;
};

const AdminRoute: React.FC<{ children: JSX.Element }> = ({ children }) => {
  const { currentUser, isLoading } = useAuth();
   if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><p className="text-slate-700">Loading...</p></div>; // Or a spinner
  }
  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }
  if (currentUser.role !== 'admin') {
    // Redirect non-admins to their default page or a generic 'access denied' page
    return <Navigate to="/inventory" replace />; 
  }
  return children;
};

const App: React.FC = () => {
  return (
    // AuthProvider is already in index.tsx, AppProvider handles app-specific state
    <AppProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/*"
            element={
              <UserRoute>
                <Layout>
                  <Routes>
                    <Route path="/" element={
                      <NavigateToRoleSpecificDashboard />
                    } />
                    <Route path="/inventory" element={<InventoryExplorer />} />
                    <Route path="/borrow-equipment" element={<UserBorrowPage />} />
                    
                    {/* Admin Specific Routes */}
                    <Route path="/dashboard" element={
                      <AdminRoute><Dashboard /></AdminRoute>
                    } />
                    <Route path="/borrowing" element={
                      <AdminRoute><BorrowingManager /></AdminRoute>
                    } />
                    <Route path="/breakage" element={
                      <AdminRoute><BreakageReport /></AdminRoute>
                    } />
                    <Route path="/missing" element={
                      <AdminRoute><MissingReport /></AdminRoute>
                    } />
                     <Route path="/login-history" element={ // New route for login history
                      <AdminRoute><LoginHistoryPage /></AdminRoute>
                    } />
                    
                    {/* Fallback for any other route within authenticated layout */}
                    <Route path="*" element={<NavigateToRoleSpecificDashboard />} /> 
                  </Routes>
                </Layout>
              </UserRoute>
            }
          />
        </Routes>
      </HashRouter>
    </AppProvider>
  );
};

// Helper component to redirect users based on their role after login to "/"
const NavigateToRoleSpecificDashboard: React.FC = () => {
  const { currentUser } = useAuth(); // No need for isLoading here, UserRoute handles it
  if (currentUser?.role === 'admin') {
    return <Navigate to="/dashboard" replace />;
  }
  // Default for 'user' role or if role is somehow undefined after login
  return <Navigate to="/inventory" replace />;
};


export default App;