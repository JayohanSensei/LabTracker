
// service-worker.js

const CACHE_NAME = 'labtrack-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  // Add other static assets you want to cache initially like main CSS/JS bundles if not CDN, key images
  // '/styles/main.css', // Example
  // '/scripts/main.js', // Example
  '/manifest.json'
  // Note: For a React app with client-side routing and code splitting, caching strategy can be more complex.
  // This basic SW is a starting point.
];

// Install a service worker
self.addEventListener('install', event => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Service Worker: Caching app shell');
        return cache.addAll(urlsToCache);
      })
      .then(() => {
        return self.skipWaiting(); // Force the waiting service worker to become the active service worker.
      })
  );
});

// Activate the service worker
self.addEventListener('activate', event => {
  console.log('Service Worker: Activating...');
  // Remove old caches
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            console.log('Service Worker: Clearing old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    }).then(() => {
      return self.clients.claim(); // Become available to all pages or tabs that load within the scope of the service worker.
    })
  );
});

// Listen for requests
self.addEventListener('fetch', event => {
  // We only want to handle GET requests for this basic cache-first strategy
  if (event.request.method !== 'GET') {
    return;
  }
  
  // Basic cache-first strategy
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          // Cache hit - return response
          // console.log('Service Worker: Serving from cache:', event.request.url);
          return response;
        }

        // Not in cache - fetch from network, then cache it
        // console.log('Service Worker: Fetching from network and caching:', event.request.url);
        return fetch(event.request).then(
          networkResponse => {
            // Check if we received a valid response
            if(!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
              return networkResponse;
            }

            // IMPORTANT: Clone the response. A response is a stream
            // and because we want the browser to consume the response
            // as well as the cache consuming the response, we need
            // to clone it so we have two streams.
            var responseToCache = networkResponse.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return networkResponse;
          }
        ).catch(error => {
          console.error('Service Worker: Fetch failed; returning offline page if available, or error', error);
          // Optionally, return a fallback offline page:
          // return caches.match('/offline.html'); 
        });
      })
  );
});
