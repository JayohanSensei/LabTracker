
import React from 'react';
import { Link } from 'react-router-dom';
import { Card } from './common/Card';
import { useAppContext } from '../contexts/AppContext';
import { InventoryItem } from '../types'; // ItemStatus no longer directly on InventoryItem

// Icons for dashboard cards
const InventoryIconSvg = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-blue-500"><path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10.5 11.25h3M12 17.25v-6M18.75 7.5H5.25c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125h13.5c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125z" /></svg>;
const BorrowIconSvg = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-green-500"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>;
const BrokenIconSvg = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-red-500"><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>;
const MissingIconSvg = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-12 h-12 text-yellow-500"><path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" /></svg>;

const StatCard: React.FC<{title: string, value: string | number, icon: React.ReactNode, color: string}> = ({title, value, icon, color}) => (
    <Card className={`border-l-4 ${color}`}>
        <div className="flex items-center">
            <div className="p-3 rounded-full bg-opacity-20" style={{backgroundColor: color.replace('border-', 'bg-').replace('-500', '-100')}}>
                {icon}
            </div>
            <div className="ml-4">
                <p className="text-sm font-medium text-slate-500/70 uppercase tracking-wider">{title}</p>
                <p className="text-3xl font-semibold text-slate-700/70">{value}</p>
            </div>
        </div>
    </Card>
);


export const Dashboard: React.FC = () => {
  const { inventory, borrowers } = useAppContext();

  const totalPhysicalItems = inventory.reduce((sum, item) => 
    sum + item.quantityAvailable + item.quantityBorrowed + item.quantityBroken + item.quantityMissing + item.quantityMaintenance, 0);
  
  const itemsBorrowedCount = inventory.reduce((sum, item) => sum + item.quantityBorrowed, 0);
  // This could also be calculated from active borrower records:
  // const itemsBorrowedCount = borrowers.filter(b => b.status === 'Borrowed').reduce((sum, b) => sum + b.quantityBorrowed, 0);
  // Using inventory.quantityBorrowed assumes it's kept in sync.

  const itemsBrokenCount = inventory.reduce((sum, item) => sum + item.quantityBroken, 0);
  const itemsMissingCount = inventory.reduce((sum, item) => sum + item.quantityMissing, 0);


  const navCards = [
    { to: '/inventory', title: 'Inventory Explorer', description: 'Browse and manage all lab equipment.', icon: <InventoryIconSvg />, count: `${inventory.length} types` },
    { to: '/borrowing', title: 'Borrowing Records', description: 'Track borrowed items and manage returns.', icon: <BorrowIconSvg />, count: `${borrowers.filter(b => b.status === 'Borrowed').length} active loans` },
    { to: '/breakage', title: 'Breakage Report', description: 'View and manage broken equipment.', icon: <BrokenIconSvg />, count: `${itemsBrokenCount} items` },
    { to: '/missing', title: 'Missing Items', description: 'Identify and report missing equipment.', icon: <MissingIconSvg />, count: `${itemsMissingCount} items` },
  ];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold text-slate-800/70">LabTrack Dashboard</h1>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Physical Items" value={totalPhysicalItems} icon={<InventoryIconSvg />} color="border-blue-500" />
        <StatCard title="Items Currently Borrowed" value={itemsBorrowedCount} icon={<BorrowIconSvg />} color="border-green-500" />
        <StatCard title="Items Reported Broken" value={itemsBrokenCount} icon={<BrokenIconSvg />} color="border-red-500" />
        <StatCard title="Items Reported Missing" value={itemsMissingCount} icon={<MissingIconSvg />} color="border-yellow-500" />
      </div>

      {/* Navigation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {navCards.map((card) => (
          <Link to={card.to} key={card.title} className="block hover:shadow-2xl transition-shadow duration-300 rounded-xl">
            <Card className="h-full flex flex-col hover:border-blue-500 border-2 border-transparent">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {card.icon}
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-slate-800/70">{card.title}</h2>
                  <p className="text-slate-600/70 mt-1">{card.description}</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t border-slate-200 text-sm text-slate-500/70">
                {card.count}
              </div>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
};
