
import React from 'react';
import { useAppContext } from '../contexts/AppContext';
import { InventoryItem, BorrowerRecord, BorrowingStatus, ReturnRemark } from '../types';
import { Card } from './common/Card';

interface CombinedMissingItem {
  id: string;
  name: string;
  type: 'Inventory' | 'Borrowing Return' | 'Overdue Borrowing';
  dateReportedMissing: string; 
  quantityMissing: number;
  lastSeenWith?: string; 
  details?: string;
  category?: string; 
}


export const MissingReport: React.FC = () => {
  const { inventory, borrowers } = useAppContext();

  const missingFromInventory: CombinedMissingItem[] = inventory
    .filter(item => item.quantityMissing > 0)
    .map(item => ({
      id: item.id,
      name: item.name,
      type: 'Inventory' as const, 
      dateReportedMissing: 'N/A (Inventory Status)', 
      quantityMissing: item.quantityMissing, 
      details: item.notes || `Marked as ${item.quantityMissing} missing in inventory.`,
      category: item.category,
    }));

  const missingFromBorrowingReturns: CombinedMissingItem[] = borrowers
    .filter(record => record.status === BorrowingStatus.RETURNED && record.remarks === ReturnRemark.INCOMPLETE)
    .map(record => ({
        id: record.id, // Borrower record ID
        name: record.instrumentName,
        type: 'Borrowing Return' as const, 
        dateReportedMissing: record.dateReturned || record.dateBorrowed, // Date of return when incompleteness was noted
        quantityMissing: record.quantityBorrowed, // Assuming entire borrowed quantity is what's being discussed for incompleteness
        lastSeenWith: record.borrowerName,
        details: record.notes || `Returned incomplete by ${record.borrowerName}. Expected ${record.quantityBorrowed}.`,
        category: inventory.find(i => i.id === record.instrumentId)?.category,
    }));
    
  const overdueBorrowedItems: CombinedMissingItem[] = borrowers
    .filter(record => record.status === BorrowingStatus.BORROWED && record.dateDue && new Date(record.dateDue) < new Date(new Date().toDateString())) // Compare date parts only for overdue
    .map(record => ({
        id: record.id, // Borrower record ID
        name: record.instrumentName,
        type: 'Overdue Borrowing' as const,
        dateReportedMissing: record.dateDue!, // Due date is the reference for "missing"
        quantityMissing: record.quantityBorrowed,
        lastSeenWith: record.borrowerName,
        details: `Overdue since ${record.dateDue}. Borrowed on ${record.dateBorrowed}. ${record.notes || ''}`.trim(),
        category: inventory.find(i => i.id === record.instrumentId)?.category,
    }));
  
  const allMissingItems: CombinedMissingItem[] = [...missingFromInventory, ...missingFromBorrowingReturns, ...overdueBorrowedItems]
    .sort((a,b) => {
        if (a.dateReportedMissing.includes('N/A') && !b.dateReportedMissing.includes('N/A')) return 1;
        if (!a.dateReportedMissing.includes('N/A') && b.dateReportedMissing.includes('N/A')) return -1;
        if (a.dateReportedMissing.includes('N/A') && b.dateReportedMissing.includes('N/A')) return 0;
        return new Date(b.dateReportedMissing).getTime() - new Date(a.dateReportedMissing).getTime();
    });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header className="p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">Missing & Overdue Items Report</h1>
        <p className="text-sm text-slate-600/70">Summary of equipment identified as missing or significantly overdue.</p>
      </header>

      {allMissingItems.length > 0 ? (
         <div className="space-y-4">
          {allMissingItems.map((item) => (
            <Card key={`${item.type}-${item.id}`} className="border-l-4 border-yellow-500">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
                <div>
                  <h3 className="text-lg font-semibold text-yellow-700/70">{item.name}</h3>
                  <p className="text-sm text-slate-500/70">Category: {item.category || 'N/A'}</p>
                   <p className="text-sm text-slate-500/70">Source: {item.type}</p>
                </div>
                <div className="text-sm text-slate-700/70">
                  <p><span className="font-medium">Quantity Affected:</span> {item.quantityMissing}</p>
                  <p><span className="font-medium">Date Identified/Due:</span> {item.dateReportedMissing}</p>
                  {item.lastSeenWith && <p><span className="font-medium">Associated With:</span> {item.lastSeenWith}</p>}
                </div>
                <div className="md:col-span-1">
                   <p className="text-sm font-medium text-slate-700/70">Details:</p>
                   <p className="text-sm text-slate-600/70 bg-slate-50 p-2 rounded break-words">{item.details || 'No specific details provided.'}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <div className="text-center py-10">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-green-500 mb-4" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-slate-600/70 text-xl">No missing or overdue items reported.</p>
            <p className="text-slate-500/70">All equipment is accounted for based on current records and due dates.</p>
          </div>
        </Card>
      )}
    </div>
  );
};
