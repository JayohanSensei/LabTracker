
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { UserRole } from '../types';

interface LayoutProps {
  children: React.ReactNode;
}

const NavLink: React.FC<{ to: string; children: React.ReactNode; icon: React.ReactNode }> = ({ to, children, icon }) => {
  const location = useLocation();
  const isActive = location.pathname === to || (location.pathname.startsWith(to) && to !== '/');
  
  return (
    <Link
      to={to}
      className={`flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-150
                  ${isActive ? 'bg-blue-600 text-white shadow-md' : 'text-slate-100/70 hover:bg-blue-500 hover:text-white'}`}
    >
      <span className="mr-3">{icon}</span>
      {children}
    </Link>
  );
};

// SVG Icons (Heroicons)
const HomeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" /></svg>;
const InventoryIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5M10.5 11.25h3M12 17.25v-6M18.75 7.5H5.25c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125h13.5c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125z" /></svg>;
const BorrowIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>;
const BorrowFormIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" /></svg>;
const BrokenIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" /></svg>;
const MissingIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M9.879 7.519c1.171-1.025 3.071-1.025 4.242 0 1.172 1.025 1.172 2.687 0 3.712-.203.179-.43.326-.67.442-.745.361-1.45.999-1.45 1.827v.75M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9 5.25h.008v.008H12v-.008z" /></svg>;
const LoginHistoryIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 002.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 00-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 00.75-.75 2.25 2.25 0 00-.1-.664m-5.8 0A2.251 2.251 0 0113.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25zM6.75 12h.008v.008H6.75V12zm0 3h.008v.008H6.75V15zm0 3h.008v.008H6.75V18z" /></svg>;

const MenuIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" /></svg>;
const CloseIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>;
const LogoutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l-3 3m0 0l3 3m-3-3h12.75" /></svg>;
const LoginIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15M12 9l3 3m0 0l-3 3m3-3H3.75" /></svg>;


export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  const baseNavItems = [
    { to: '/inventory', label: 'Inventory Explorer', icon: <InventoryIcon />, roles: ['user', 'admin'] as UserRole[] },
    { to: '/borrow-equipment', label: 'Borrow Equipment', icon: <BorrowFormIcon />, roles: ['user'] as UserRole[] },
  ];

  const adminNavItems = [
    { to: '/dashboard', label: 'Dashboard', icon: <HomeIcon />, roles: ['admin'] as UserRole[] },
    { to: '/borrowing', label: 'Borrowing Records', icon: <BorrowIcon />, roles: ['admin'] as UserRole[] },
    { to: '/breakage', label: 'Breakage Report', icon: <BrokenIcon />, roles: ['admin'] as UserRole[] },
    { to: '/missing', label: 'Missing Items Report', icon: <MissingIcon />, roles: ['admin'] as UserRole[] },
    { to: '/login-history', label: 'Login History', icon: <LoginHistoryIcon />, roles: ['admin'] as UserRole[] },
  ];

  let navItems = [];
  if (currentUser) {
    if (currentUser.role === 'admin') {
      // Admin sees all admin items + any base items also marked for admin
      const adminSpecificBaseItems = baseNavItems.filter(item => item.roles.includes('admin'));
      // Combine and ensure inventory is correctly placed if it's in both
      navItems = [
          ...adminNavItems.filter(item => item.to !== '/inventory'), // Add admin items, excluding inventory for now
          ...adminSpecificBaseItems, // Add base items for admin (includes inventory)
      ].sort((a,b) => { // Optional: specific sort order
          const order = ['/dashboard', '/inventory', '/borrowing', '/login-history', '/breakage', '/missing'];
          return order.indexOf(a.to) - order.indexOf(b.to);
      });
      // Deduplicate if needed, though structure above should handle it if '/inventory' is defined once for admin
       const uniqueNavItems = [];
       const seenPaths = new Set();
       for (const item of navItems) {
           if (!seenPaths.has(item.to)) {
               uniqueNavItems.push(item);
               seenPaths.add(item.to);
           }
       }
       navItems = uniqueNavItems;


    } else { // 'user' role
      navItems = baseNavItems.filter(item => item.roles.includes('user'));
    }
  }


  if (!currentUser && location.pathname !== '/login') {
     return <>{children}</>; 
  }


  return (
    <div className="flex h-screen bg-slate-100">
      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-slate-800 text-white/70 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:relative md:translate-x-0 md:block flex flex-col`}>
        <div className="p-4 flex justify-between items-center md:justify-center border-b border-slate-700">
           <Link to="/" className="text-2xl font-bold text-white/90 flex items-center">
            <img src="/assets/labtrack_logo.png" alt="LabTrack Logo" className="w-8 h-8 mr-2 rounded" />
            LabTrack
          </Link>
          <button onClick={() => setSidebarOpen(false)} className="md:hidden text-slate-300/70 hover:text-white">
            <CloseIcon />
          </button>
        </div>
        
        <nav className="mt-6 px-2 space-y-1 flex-grow">
          {navItems.map((item) => (
            <NavLink key={item.to} to={item.to} icon={item.icon}>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-2 py-4 border-t border-slate-700">
            {currentUser && (
                 <div className="px-4 py-3 mb-2 text-xs text-slate-300/70 break-all">
                    Logged in as: <strong className="text-slate-100/90">{currentUser.email}</strong> ({currentUser.role})
                 </div>
            )}
            {currentUser ? (
                 <button
                    onClick={handleLogout}
                    className="flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg text-slate-100/70 hover:bg-red-600 hover:text-white transition-colors duration-150"
                  >
                  <LogoutIcon />
                  <span className="ml-3">Logout</span>
                </button>
            ) : (
                 <NavLink to="/login" icon={<LoginIcon />}>Login</NavLink>
            )}
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar for mobile */}
        <header className="md:hidden bg-white shadow-md p-4 flex justify-between items-center">
          <Link to="/" className="text-xl font-bold text-slate-800/70 flex items-center">
             <img src="/assets/labtrack_logo.png" alt="LabTrack Logo" className="w-7 h-7 mr-2 rounded" />
            LabTrack
          </Link>
          <button onClick={() => setSidebarOpen(true)} className="text-slate-600 hover:text-slate-800">
            <MenuIcon />
          </button>
        </header>

        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-slate-100 p-6">
          {children}
        </main>
      </div>
       {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden" 
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
};