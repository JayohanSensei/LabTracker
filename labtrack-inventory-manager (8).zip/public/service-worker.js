
// service-worker.js

const CACHE_NAME = 'labtrack-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  // Add other static assets you want to cache initially like main CSS/JS bundles if not CDN, key images
  // '/styles/main.css', // Example
  // '/scripts/main.js', // Example
  '/manifest.json', // This path will resolve correctly as Vite serves public/manifest.json at /manifest.json
  '/assets/labtrack_logo.png', // Cache the logo
  // Note: For a React app with client-side routing and code splitting, caching strategy can be more complex.
  // Vite PWA plugins can help manage this more effectively.
  // For now, ensure your build output (e.g., main JS/CSS chunks) are also cached if desired.
  // Vite usually hashes filenames, so you might need a more dynamic way to add them or use a Vite PWA plugin.
];

// Install a service worker
self.addEventListener('install', event => {
  console.log('Service Worker: Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Service Worker: Caching app shell');
        // Filter out any undefined or null URLs before calling addAll
        const validUrlsToCache = urlsToCache.filter(url => url);
        return cache.addAll(validUrlsToCache);
      })
      .then(() => {
        return self.skipWaiting(); // Force the waiting service worker to become the active service worker.
      })
      .catch(error => {
        console.error('Service Worker: Cache addAll failed during install:', error);
      })
  );
});

// Activate the service worker
self.addEventListener('activate', event => {
  console.log('Service Worker: Activating...');
  // Remove old caches
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            console.log('Service Worker: Clearing old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    }).then(() => {
      return self.clients.claim(); // Become available to all pages or tabs that load within the scope of the service worker.
    })
  );
});

// Listen for requests
self.addEventListener('fetch', event => {
  // We only want to handle GET requests for this basic cache-first strategy
  if (event.request.method !== 'GET') {
    return;
  }
  
  // For navigation requests, try network first, then cache (Network-first for HTML)
  // This helps ensure users get the latest HTML if online.
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then(networkResponse => {
          // Check if we received a valid response
          if (networkResponse && networkResponse.ok) {
             // IMPORTANT: Clone the response.
            const responseToCache = networkResponse.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, responseToCache);
            });
          }
          return networkResponse;
        })
        .catch(() => {
          // Network failed, try to serve from cache
          return caches.match(event.request);
        })
    );
    return;
  }

  // Basic cache-first strategy for other assets (CSS, JS, images)
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        if (response) {
          // Cache hit - return response
          return response;
        }

        // Not in cache - fetch from network, then cache it
        return fetch(event.request).then(
          networkResponse => {
            // Check if we received a valid response
            if(!networkResponse || networkResponse.status !== 200) {
              // Don't cache non-200 responses unless it's an opaque response you specifically want to cache
              if (networkResponse.type !== 'opaque') { // Opaque responses are from cross-origin requests without CORS
                 return networkResponse;
              }
            }
            
            // For basic types or specifically handled opaque responses
            if (networkResponse.type === 'basic' || networkResponse.type === 'cors' || networkResponse.type === 'opaque') {
                const responseToCache = networkResponse.clone();
                caches.open(CACHE_NAME)
                  .then(cache => {
                    cache.put(event.request, responseToCache);
                  });
            }
            return networkResponse;
          }
        ).catch(error => {
          console.error('Service Worker: Fetch failed; error:', error);
          // Optionally, return a fallback offline page/image here for specific asset types
        });
      })
  );
});
