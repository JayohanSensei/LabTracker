
import React, { useState } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { BorrowingForm } from './BorrowingForm';
import { BorrowingList } from './BorrowingList';
import { Button } from './common/Button';

// This page is now Admin-only, controlled by AdminRoute in App.tsx
// Admins might still use the BorrowingForm here to record on behalf of someone.
export const BorrowingManager: React.FC = () => {
  const { borrowers } = useAppContext();
  const [showForm, setShowForm] = useState(false);

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">Borrowing Records Management (Admin)</h1>
        <Button onClick={() => setShowForm(!showForm)} variant="primary">
          {showForm ? 'Hide Form' : 'Add New Borrowing Record'}
        </Button>
      </header>
      
      {showForm && <BorrowingForm onFormSubmit={() => setShowForm(false)} />}
      
      <BorrowingList borrowers={borrowers} />
    </div>
  );
};
