
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Button } from './common/Button';
import { Textarea } from './common/Textarea';
import { Card } from './common/Card';

interface Message {
  id: string;
  sender: 'user' | 'ai' | 'system' | 'error';
  text: string;
}

// Icons (can be moved to a shared icons file if used elsewhere)
const UserIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 flex-shrink-0 rounded-full bg-blue-500 text-white p-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" /></svg>;
const AiIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 flex-shrink-0 rounded-full bg-slate-700 text-white p-0.5"><path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" /></svg>;
const SendIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" /></svg>;


export const AILabAssistant: React.FC = () => {
  const [userInput, setUserInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { id: 'system-intro', sender: 'system', text: 'Hello! I am your AI Lab Assistant. Ask me about lab procedures, equipment, or scientific concepts.' }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const chatHistoryRef = useRef<HTMLDivElement>(null);

  // Ensure API_KEY is available. Vite replaces process.env.API_KEY with its value at build time.
  if (!process.env.API_KEY) {
    return (
        <div className="max-w-3xl mx-auto p-4 text-center">
            <Card>
                <h1 className="text-xl font-semibold text-red-600">Configuration Error</h1>
                <p className="text-slate-700 mt-2">The AI Lab Assistant cannot be initialized. The API key is missing.</p>
                <p className="text-sm text-slate-500 mt-1">Please ensure the API_KEY environment variable is set.</p>
            </Card>
        </div>
    );
  }
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });


  useEffect(() => {
    if (chatHistoryRef.current) {
      chatHistoryRef.current.scrollTop = chatHistoryRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!userInput.trim()) return;

    const newUserMessage: Message = { id: `user-${Date.now()}`, sender: 'user', text: userInput.trim() };
    setMessages(prev => [...prev, newUserMessage]);
    const currentInput = userInput.trim();
    setUserInput('');
    setIsLoading(true);

    try {
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17',
        contents: currentInput,
        config: {
          systemInstruction: "You are a helpful and knowledgeable AI Lab Assistant for the LabTrack application. Your primary role is to provide clear, concise, and accurate information related to laboratory procedures, the usage and function of common lab instruments (biology, chemistry, physics), basic scientific concepts, and lab safety guidelines. Do not answer questions outside of this scope. If you are unsure or a question is unrelated, politely state that you cannot answer.",
        }
      });
      
      const aiResponseText = response.text;
      const newAiMessage: Message = { id: `ai-${Date.now()}`, sender: 'ai', text: aiResponseText };
      setMessages(prev => [...prev, newAiMessage]);

    } catch (error) {
      console.error("Gemini API error:", error);
      const errorMessageText = error instanceof Error ? error.message : "An unknown error occurred.";
      const errorMessage: Message = { 
        id: `error-${Date.now()}`, 
        sender: 'error', 
        text: `Sorry, I encountered an error: ${errorMessageText}. Please try again.` 
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const getMessageStyles = (sender: Message['sender']) => {
    switch (sender) {
      case 'user':
        return {
          container: 'ml-auto justify-end',
          bubble: 'bg-blue-600 text-white rounded-br-none',
          icon: <UserIcon />
        };
      case 'ai':
        return {
          container: 'mr-auto justify-start',
          bubble: 'bg-slate-200 text-slate-800 rounded-bl-none',
          icon: <AiIcon />
        };
      case 'system':
        return {
          container: 'mx-auto justify-center',
          bubble: 'bg-slate-100 text-slate-600 italic text-sm text-center px-4 py-2',
          icon: null
        };
      case 'error':
         return {
          container: 'mr-auto justify-start',
          bubble: 'bg-red-100 text-red-700 rounded-bl-none border border-red-300',
          icon: <AiIcon /> // Or a specific error icon
        };
      default:
        return {
          container: 'mr-auto justify-start',
          bubble: 'bg-gray-200 text-gray-800 rounded-bl-none',
          icon: <AiIcon />
        };
    }
  };


  return (
    <div className="max-w-3xl mx-auto h-full flex flex-col">
      <header className="p-4 bg-white shadow rounded-lg text-center sticky top-0 z-10">
        <h1 className="text-3xl font-bold text-slate-800/70">AI Lab Assistant</h1>
        <p className="text-md text-slate-600/70 mt-1">Your intelligent partner for lab queries.</p>
      </header>
      
      <Card className="flex flex-col flex-grow mt-6 overflow-hidden"> {/* Ensure card takes up remaining space */}
        <div ref={chatHistoryRef} className="flex-grow p-4 space-y-3 overflow-y-auto">
          {messages.map((msg) => {
            const styles = getMessageStyles(msg.sender);
            return (
              <div
                key={msg.id}
                className={`flex items-end gap-2 max-w-[85%] md:max-w-[75%] ${styles.container}`}
                role="log"
                aria-live={msg.sender === 'ai' || msg.sender === 'error' ? 'polite' : undefined}
              >
                {styles.icon && msg.sender !== 'user' && (
                    <div className="flex-shrink-0 self-start">{styles.icon}</div>
                )}
                <div className={`p-3 rounded-xl shadow-sm ${styles.bubble} break-words`}>
                  {msg.text.split('\\n').map((line, index) => (
                    <span key={index}>{line}<br/></span>
                  ))}
                </div>
                 {styles.icon && msg.sender === 'user' && (
                    <div className="flex-shrink-0 self-start">{styles.icon}</div>
                )}
              </div>
            );
          })}
           {isLoading && (
            <div className={`flex items-end gap-2 max-w-[85%] md:max-w-[75%] mr-auto justify-start`}>
              <div className="flex-shrink-0 self-start"><AiIcon /></div>
              <div className="p-3 rounded-xl shadow-sm bg-slate-200 text-slate-800 rounded-bl-none italic">
                AI is thinking...
              </div>
            </div>
          )}
        </div>
        
        <div className="p-4 border-t border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-2">
            <Textarea
              id="userInput"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              placeholder="Ask about lab procedures, instruments, etc."
              className="flex-grow !mb-0"
              wrapperClassName="!mb-0 flex-grow"
              rows={1} // Start with 1 row, auto-expands with content
              onKeyPress={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              disabled={isLoading}
              aria-label="Type your question for the AI Lab Assistant"
              style={{resize: 'none'}} // Prevent manual resize if desired
            />
            <Button 
              onClick={handleSendMessage} 
              disabled={isLoading || !userInput.trim()} 
              size="md" // Adjusted size
              className="px-4 py-2 self-end" // Ensure vertical alignment
              aria-label="Send message"
            >
              <SendIcon />
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
};
