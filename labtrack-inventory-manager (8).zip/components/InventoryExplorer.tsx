
import React, { useState, useMemo } from 'react';
import { useAppContext } from '../contexts/AppContext';
import { InventoryItem, LabCategory } from '../types';
import { InventoryItemCard } from './InventoryItemCard';
import { InventoryEditModal } from './InventoryEditModal';
import { Input } from './common/Input';
import { Select } from './common/Select';
import { LAB_CATEGORIES } from '../constants';
import { useAuth } from '../contexts/AuthContext';

export const InventoryExplorer: React.FC = () => {
  const { inventory } = useAppContext();
  const { currentUser } = useAuth();
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<LabCategory | ''>('');

  const isAdmin = currentUser?.role === 'admin';

  const handleViewDetails = (item: InventoryItem) => {
    if (isAdmin) { // Only admins can open the edit modal
      setSelectedItem(item);
      setIsModalOpen(true);
    }
    // For users, clicking the card (if a button were present) might show a read-only view in the future.
    // For now, non-admins won't see the button that calls this for editing.
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedItem(null);
  };

  const filteredInventory = useMemo(() => {
    return inventory.filter(item => {
      const matchesSearchTerm = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                                (item.notes && item.notes.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesCategory = selectedCategory ? item.category === selectedCategory : true;
      return matchesSearchTerm && matchesCategory;
    });
  }, [inventory, searchTerm, selectedCategory]);

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">Inventory Explorer</h1>
        <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
          <Input 
            placeholder="Search items..." 
            value={searchTerm} 
            onChange={(e) => setSearchTerm(e.target.value)}
            wrapperClassName="mb-0 flex-grow"
            className="min-w-[200px]"
            aria-label="Search inventory items"
          />
          <Select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as LabCategory | '')}
            options={[{ value: '', label: 'All Categories' }, ...LAB_CATEGORIES.map(cat => ({ value: cat, label: cat }))]}
            wrapperClassName="mb-0 flex-grow"
            className="min-w-[200px]"
            placeholder="All Categories"
            aria-label="Filter by category"
          />
        </div>
      </header>

      {filteredInventory.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {filteredInventory.map(item => (
            <InventoryItemCard key={item.id} item={item} onViewDetails={handleViewDetails} />
          ))}
        </div>
      ) : (
        <div className="text-center py-10">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-slate-400 mb-4" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
          </svg>
          <p className="text-slate-600/70 text-xl">No items found matching your criteria.</p>
          <p className="text-slate-500/70">Try adjusting your search or filter settings.</p>
        </div>
      )}

      {isAdmin && selectedItem && ( // Modal is only rendered and relevant for admins
        <InventoryEditModal
          isOpen={isModalOpen}
          onClose={closeModal}
          item={selectedItem}
        />
      )}
    </div>
  );
};
