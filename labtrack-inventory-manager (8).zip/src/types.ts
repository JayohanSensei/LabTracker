
export enum LabCategory {
  BIOLOGY = 'Biology',
  CHEMISTRY = 'Chemistry',
  PHYSICS = 'Physics',
}

export enum ItemStatus {
  AVAILABLE = 'Available',
  BORROWED = 'Borrowed', // Represents items currently out on loan
  BROKEN = 'Broken',
  MISSING = 'Missing',
  MAINTENANCE = 'Maintenance',
}

export interface InventoryItem {
  id: string;
  name: string;
  category: LabCategory;
  imageUrl: string;
  description: string; // Functions
  labSetup?: string; // Possible lab setup or companions
  quantityLastYear: number; // Total quantity at the start of the year/period

  // Specific quantities for each status
  quantityAvailable: number;
  quantityBorrowed: number; // Sum of quantities from active borrower records
  quantityBroken: number;
  quantityMissing: number;
  quantityMaintenance: number;

  notes?: string; // For additional details or general notes about the item type
}

export enum BorrowerRole {
  STUDENT = 'Student',
  FACULTY = 'Faculty',
  // USER = 'Registered User' // Could add if differentiating internal roles vs app users
}

export enum BorrowingStatus {
  BORROWED = 'Borrowed', // Item is currently out
  RETURNED = 'Returned',
}

export enum ReturnRemark {
  COMPLETE = 'Complete',
  INCOMPLETE = 'Incomplete', // Some quantity missing or item slightly damaged but usable
  BROKEN = 'Broken', // Item returned broken
}

export interface BorrowerRecord {
  id: string;
  borrowerName: string; // Could be user's email or display name if linked to User accounts
  borrowerRole: BorrowerRole;
  borrowerId?: string; // Optional: Link to User ID
  gradeLevel?: string; // e.g., "Grade 10", "BS Biology 3rd Year"
  instrumentId: string;
  instrumentName: string; // For display convenience
  quantityBorrowed: number;
  dateBorrowed: string; // ISO string or YYYY-MM-DD
  dateDue?: string; // Optional
  dateReturned?: string; // ISO string or YYYY-MM-DD
  status: BorrowingStatus;
  remarks?: ReturnRemark;
  notes?: string; // For any specific notes about this borrowing record
}

export interface AppContextType {
  inventory: InventoryItem[];
  setInventory: React.Dispatch<React.SetStateAction<InventoryItem[]>>;
  borrowers: BorrowerRecord[];
  setBorrowers: React.Dispatch<React.SetStateAction<BorrowerRecord[]>>;
  addBorrowerRecord: (record: Omit<BorrowerRecord, 'id' | 'instrumentName' | 'status'>) => void;
  updateBorrowerRecord: (updatedRecord: BorrowerRecord) => void;
  updateInventoryItem: (updatedItem: InventoryItem) => void;
  getInstrumentById: (id: string) => InventoryItem | undefined;
}

// --- Authentication Types ---
export type UserRole = 'user' | 'admin';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  // IMPORTANT: In a real app, never store passwords in plaintext. This is for demo purposes.
  // Passwords should be securely hashed and salted on the server.
  password?: string; // Only used during signup/local storage for this demo
}

export interface LoginAttempt {
  id: string;
  email: string;
  timestamp: string; // ISO string format
  success: boolean;
}

export interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loginHistory: LoginAttempt[]; // Added for admins to view login attempts
}
