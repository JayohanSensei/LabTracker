

import React, { useState, useEffect } from 'react';
import { InventoryItem, LabCategory } from '../types';
import { useAppContext } from '../contexts/AppContext';
import { Modal } from './common/Modal';
import { Button } from './common/Button';
import { Input } from './common/Input';
import { Select } from './common/Select';
import { Textarea } from './common/Textarea';
import { LAB_CATEGORIES } from '../constants';

interface InventoryEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: InventoryItem | null;
}

export const InventoryEditModal: React.FC<InventoryEditModalProps> = ({ isOpen, onClose, item }) => {
  const { updateInventoryItem } = useAppContext();
  const [editedItem, setEditedItem] = useState<InventoryItem | null>(null);

  useEffect(() => {
    if (item) {
      setEditedItem({ ...item });
    } else {
      setEditedItem(null);
    }
  }, [item]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    if (!editedItem) return;
    const { name, value } = e.target;
    
    const numericFields = [
      'quantityLastYear', 
      'quantityAvailable', 
      'quantityBorrowed', // Should not be directly editable through this form for accuracy
      'quantityBroken', 
      'quantityMissing', 
      'quantityMaintenance'
    ];

    if (numericFields.includes(name)) {
      setEditedItem(prev => prev ? { ...prev, [name]: parseInt(value) || 0 } : null);
    } else {
      setEditedItem(prev => prev ? { ...prev, [name]: value } : null);
    }
  };

  const handleSave = () => {
    if (editedItem) {
      // Potentially recalculate total or validate quantities here if needed
      updateInventoryItem(editedItem);
      onClose();
    }
  };

  if (!isOpen || !editedItem) return null;

  const totalCurrentPhysicalStock = 
    editedItem.quantityAvailable + 
    editedItem.quantityBorrowed + 
    editedItem.quantityBroken + 
    editedItem.quantityMissing + 
    editedItem.quantityMaintenance;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Edit: ${editedItem.name}`} size="xl">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <img src={editedItem.imageUrl} alt={editedItem.name} className="w-full h-64 object-contain rounded-md mb-4 bg-slate-100" />
          <Input label="Image URL" name="imageUrl" value={editedItem.imageUrl} onChange={handleChange} />
        </div>
        <div className="space-y-4">
          <Input label="Item Name" name="name" value={editedItem.name} onChange={handleChange} />
          <Select
            label="Category"
            name="category"
            value={editedItem.category}
            onChange={handleChange}
            options={LAB_CATEGORIES.map(cat => ({ value: cat, label: cat }))}
          />
          <Textarea label="Description (Functions)" name="description" value={editedItem.description} onChange={handleChange} rows={3} />
          <Textarea label="Lab Setup / Companions" name="labSetup" value={editedItem.labSetup || ''} onChange={handleChange} rows={2} />
        </div>
      </div>
      
      <div className="mt-6 border-t pt-6">
        <h4 className="text-md font-semibold text-slate-700/70 mb-3">Quantity Management</h4>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <Input type="number" label="Qty Last Year (Ref.)" name="quantityLastYear" value={editedItem.quantityLastYear.toString()} onChange={handleChange} />
          <Input type="number" label="Qty Available" name="quantityAvailable" value={editedItem.quantityAvailable.toString()} onChange={handleChange} 
            className="border-green-500 focus:ring-green-500 focus:border-green-500"
          />
          <Input type="number" label="Qty Borrowed (System)" name="quantityBorrowed" value={editedItem.quantityBorrowed.toString()} readOnly 
            className="bg-slate-100 border-yellow-500"
          />
          <Input type="number" label="Qty Broken" name="quantityBroken" value={editedItem.quantityBroken.toString()} onChange={handleChange} 
            className="border-red-500 focus:ring-red-500 focus:border-red-500"
          />
          <Input type="number" label="Qty Missing" name="quantityMissing" value={editedItem.quantityMissing.toString()} onChange={handleChange} 
             className="border-orange-500 focus:ring-orange-500 focus:border-orange-500"
          />
          <Input type="number" label="Qty Maintenance" name="quantityMaintenance" value={editedItem.quantityMaintenance.toString()} onChange={handleChange} 
             className="border-blue-500 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        <div className="mt-4 p-3 bg-slate-50 rounded-md">
            <p className="text-sm text-slate-600/70">
                Total Current Physical Stock: <span className="font-bold text-slate-800/70">{totalCurrentPhysicalStock}</span>
            </p>
            <p className="text-xs text-slate-500/70">This is the sum of Available, Borrowed, Broken, Missing, and Maintenance quantities.</p>
        </div>
      </div>
      
      <Textarea label="Notes" name="notes" value={editedItem.notes || ''} onChange={handleChange} className="mt-4" />
      
      <div className="mt-8 flex justify-end space-x-3">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button variant="primary" onClick={handleSave}>Save Changes</Button>
      </div>
    </Modal>
  );
};
