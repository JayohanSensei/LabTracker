import React, { useState, ChangeEvent } from 'react'; // Added ChangeEvent
import { BorrowerRecord, BorrowingStatus, ReturnRemark } from '../types';
import { useAppContext } from '../contexts/AppContext';
import { Button } from './common/Button';
import { Modal } from './common/Modal';
import { Select } from './common/Select';
import { Input } from './common/Input';
import { RETURN_REMARKS } from '../constants';

interface BorrowingListProps {
  borrowers: BorrowerRecord[];
}

const StatusBadge: React.FC<{ status: BorrowingStatus; remarks?: ReturnRemark }> = ({ status, remarks }) => {
  let bgColor = '';
  let textColorClass = ''; // Changed to textColorClass to avoid conflict
  let displayText: string; 

  if (status === BorrowingStatus.BORROWED) {
    bgColor = 'bg-yellow-100';
    textColorClass = 'text-yellow-800/70';
    displayText = BorrowingStatus.BORROWED;
  } else if (status === BorrowingStatus.RETURNED) {
    if (remarks === ReturnRemark.COMPLETE) {
      bgColor = 'bg-green-100';
      textColorClass = 'text-green-800/70';
      displayText = 'Returned (Complete)';
    } else if (remarks === ReturnRemark.INCOMPLETE) {
      bgColor = 'bg-orange-100';
      textColorClass = 'text-orange-800/70';
      displayText = 'Returned (Incomplete)';
    } else if (remarks === ReturnRemark.BROKEN) {
      bgColor = 'bg-red-100';
      textColorClass = 'text-red-800/70';
      displayText = 'Returned (Broken)';
    } else {
      bgColor = 'bg-slate-100';
      textColorClass = 'text-slate-800/70';
      displayText = BorrowingStatus.RETURNED; 
    }
  } else {
     bgColor = 'bg-gray-200';
     textColorClass = 'text-gray-800/70';
     displayText = String(status); 
  }

  return <span className={`px-3 py-1 text-xs font-semibold rounded-full ${bgColor} ${textColorClass}`}>{displayText}</span>;
};


export const BorrowingList: React.FC<BorrowingListProps> = ({ borrowers }) => {
  const { updateBorrowerRecord } = useAppContext();
  const [selectedRecord, setSelectedRecord] = useState<BorrowerRecord | null>(null);
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnDate, setReturnDate] = useState(new Date().toISOString().split('T')[0]);
  const [returnRemarks, setReturnRemarks] = useState<ReturnRemark | ''>('');
  const [returnNotes, setReturnNotes] = useState('');


  const openReturnModal = (record: BorrowerRecord) => {
    setSelectedRecord(record);
    setReturnDate(new Date().toISOString().split('T')[0]);
    setReturnRemarks('');
    setReturnNotes(record.notes || '');
    setIsReturnModalOpen(true);
  };

  const handleReturnSubmit = () => {
    if (selectedRecord && returnRemarks) {
      updateBorrowerRecord({
        ...selectedRecord,
        status: BorrowingStatus.RETURNED,
        dateReturned: returnDate,
        remarks: returnRemarks as ReturnRemark, 
        notes: returnNotes,
      });
      setIsReturnModalOpen(false);
      setSelectedRecord(null);
    } else {
      alert("Please select remarks for the return.");
    }
  };

  if (borrowers.length === 0) {
    return <p className="text-slate-600/70 text-center py-8">No borrowing records yet.</p>;
  }

  return (
    <div className="bg-white shadow-md rounded-lg overflow-x-auto">
      <table className="min-w-full divide-y divide-slate-200">
        <thead className="bg-slate-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Borrower</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Instrument</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Qty</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Date Borrowed</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Date Due</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Status</th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Actions</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-slate-200">
          {borrowers.map((record) => (
            <tr key={record.id} className="hover:bg-slate-50 transition-colors">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-slate-900/70">{record.borrowerName}</div>
                <div className="text-xs text-slate-500/70">{record.borrowerRole}{record.gradeLevel ? ` - ${record.gradeLevel}` : ''}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{record.instrumentName}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{record.quantityBorrowed}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{record.dateBorrowed}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{record.dateDue || 'N/A'}</td>
              <td className="px-6 py-4 whitespace-nowrap">
                <StatusBadge status={record.status} remarks={record.remarks} />
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                {record.status === BorrowingStatus.BORROWED && (
                  <Button variant="secondary" size="sm" onClick={() => openReturnModal(record)}>Mark as Returned</Button>
                )}
                 {record.status === BorrowingStatus.RETURNED && (
                   <span className="text-xs text-slate-400/70">Returned on {record.dateReturned}</span>
                 )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {selectedRecord && (
        <Modal isOpen={isReturnModalOpen} onClose={() => setIsReturnModalOpen(false)} title={`Return: ${selectedRecord.instrumentName}`}>
            <div className="space-y-4">
                <p className="text-slate-700/70">Borrower: <span className="font-semibold">{selectedRecord.borrowerName}</span></p>
                <p className="text-slate-700/70">Instrument: <span className="font-semibold">{selectedRecord.instrumentName}</span> (Qty: {selectedRecord.quantityBorrowed})</p>
                <Input type="date" label="Date Returned" value={returnDate} onChange={e => setReturnDate(e.target.value)} />
                <Select 
                    label="Remarks*"
                    value={returnRemarks}
                    onChange={(e: ChangeEvent<HTMLSelectElement>) => setReturnRemarks(e.target.value as ReturnRemark)}
                    options={RETURN_REMARKS.map(r => ({value: r, label: r}))}
                    placeholder="Select remark"
                    required
                />
                 <Input label="Notes for Return" name="returnNotes" value={returnNotes} onChange={(e) => setReturnNotes(e.target.value)} />
                <div className="flex justify-end space-x-2 mt-6">
                    <Button variant="ghost" onClick={() => setIsReturnModalOpen(false)}>Cancel</Button>
                    <Button variant="primary" onClick={handleReturnSubmit} disabled={!returnRemarks}>Confirm Return</Button>
                </div>
            </div>
        </Modal>
      )}
    </div>
  );
};
