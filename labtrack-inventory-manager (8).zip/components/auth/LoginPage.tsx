
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Input } from '../common/Input';
import { Button } from '../common/Button';
import { Card } from '../common/Card';

export const LoginPage: React.FC = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();
  const { login, signup, currentUser } = useAuth();

  // Redirect if already logged in
  if (currentUser) {
     navigate(currentUser.role === 'admin' ? '/dashboard' : '/inventory');
  }


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    if (isLoginView) {
      const success = await login(email, password);
      if (success) {
        // Navigation will be handled by currentUser effect in App.tsx or a role-based redirector
        // For now, let's assume successful login will trigger a redirect based on role via NavigateToRoleSpecificDashboard
        navigate('/'); 
      } else {
        setError('Invalid email or password.');
      }
    } else {
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        setIsLoading(false);
        return;
      }
      const success = await signup(email, password);
      if (success) {
        navigate('/'); // Navigate to default user page after signup
      } else {
        setError('Failed to create account. Email may already be in use.');
      }
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center items-center p-4">
      <div className="text-center mb-8">
        <img src="/assets/labtrack_logo.png" alt="LabTrack Logo" className="w-16 h-16 mx-auto rounded-md" />
        <h1 className="text-4xl font-bold text-slate-800/70 mt-2">LabTrack</h1>
        <p className="text-slate-600/70">Laboratory Inventory Management</p>
      </div>
      <Card className="w-full max-w-md">
        <div className="p-6 sm:p-8">
          <h2 className="text-2xl font-semibold text-slate-700/70 text-center mb-6">
            {isLoginView ? 'Welcome Back!' : 'Create Account'}
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && <p className="text-red-500/70 bg-red-100 p-3 rounded-md text-sm">{error}</p>}
            <Input
              id="email"
              label="Email Address"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
            <Input
              id="password"
              label="Password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete={isLoginView ? "current-password" : "new-password"}
            />
            {!isLoginView && (
              <Input
                id="confirmPassword"
                label="Confirm Password"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                autoComplete="new-password"
              />
            )}
            <Button type="submit" variant="primary" className="w-full" disabled={isLoading}>
              {isLoading ? (isLoginView ? 'Logging in...' : 'Signing up...') : (isLoginView ? 'Login' : 'Sign Up')}
            </Button>
          </form>
          <p className="text-sm text-slate-600/70 text-center mt-6">
            {isLoginView ? "Don't have an account?" : 'Already have an account?'}
            <button
              onClick={() => { setIsLoginView(!isLoginView); setError('');}}
              className="font-medium text-blue-600 hover:text-blue-500 ml-1"
            >
              {isLoginView ? 'Sign Up' : 'Login'}
            </button>
          </p>
        </div>
      </Card>
      <p className="text-xs text-slate-500/70 mt-8 text-center">
        Admin demo account: <span className="font-medium">admin@labtrack.com</span> / <span className="font-medium">LabTrackAyohan123</span>
      </p>
    </div>
  );
};
