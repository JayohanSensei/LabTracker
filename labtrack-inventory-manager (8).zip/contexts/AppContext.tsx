
import React, { createContext, useContext, useState, ReactNode, useCallback, useEffect } from 'react';
import { InventoryItem, BorrowerRecord, AppContextType, BorrowerRole, BorrowingStatus, ItemStatus, ReturnRemark } from '../types';
import { INITIAL_INVENTORY_DATA, INITIAL_BORROWER_DATA } from '../constants';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    // Initialize inventory and then adjust for initial borrowed items
    let initialInventory = INITIAL_INVENTORY_DATA.map(item => ({...item})); // Deep copy to avoid mutating constant

    INITIAL_BORROWER_DATA.forEach(record => {
      if (record.status === BorrowingStatus.BORROWED) {
        const itemIndex = initialInventory.findIndex(invItem => invItem.id === record.instrumentId);
        if (itemIndex !== -1) {
          const item = initialInventory[itemIndex];
          if (item.quantityAvailable >= record.quantityBorrowed) {
            item.quantityAvailable -= record.quantityBorrowed;
            item.quantityBorrowed += record.quantityBorrowed;
          } else {
            // This case should ideally not happen with well-formed initial data
            // If it does, it implies more items are borrowed than available initially.
            // For now, borrow what's available and log, or adjust logic as needed.
            console.warn(`Initial borrow for ${item.name} (qty: ${record.quantityBorrowed}) exceeds available stock (${item.quantityAvailable}). Adjusting.`);
            item.quantityBorrowed += item.quantityAvailable;
            item.quantityAvailable = 0;
          }
          initialInventory[itemIndex] = item;
        }
      }
    });
    return initialInventory;
  });
  const [borrowers, setBorrowers] = useState<BorrowerRecord[]>(INITIAL_BORROWER_DATA);

  const getInstrumentById = useCallback((id: string) => {
    return inventory.find(item => item.id === id);
  }, [inventory]);

  const updateInventoryItem = useCallback((updatedItem: InventoryItem) => {
    setInventory(prev => prev.map(item => (item.id === updatedItem.id ? updatedItem : item)));
  }, []);

  const addBorrowerRecord = useCallback((record: Omit<BorrowerRecord, 'id' | 'instrumentName' | 'status'>) => {
    const instrument = getInstrumentById(record.instrumentId);
    if (!instrument) {
      console.error("Instrument not found for borrowing:", record.instrumentId);
      return;
    }
    if (instrument.quantityAvailable < record.quantityBorrowed) {
      console.error("Not enough quantity available for:", instrument.name);
      // alert for UI can be handled in the form component
      throw new Error(`Not enough ${instrument.name} in stock. Available: ${instrument.quantityAvailable}`);
    }

    const newRecord: BorrowerRecord = {
      ...record,
      id: `borrow-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      instrumentName: instrument.name,
      status: BorrowingStatus.BORROWED,
    };
    setBorrowers(prev => [newRecord, ...prev]);
    
    setInventory(prevInventory =>
      prevInventory.map(item =>
        item.id === record.instrumentId
          ? { 
              ...item, 
              quantityAvailable: item.quantityAvailable - record.quantityBorrowed,
              quantityBorrowed: item.quantityBorrowed + record.quantityBorrowed,
            }
          : item
      )
    );
  }, [getInstrumentById, inventory]);

  const updateBorrowerRecord = useCallback((updatedRecord: BorrowerRecord) => {
    const originalRecord = borrowers.find(r => r.id === updatedRecord.id);
    setBorrowers(prev => prev.map(record => (record.id === updatedRecord.id ? updatedRecord : record)));

    // If item is being returned (status changes from Borrowed to Returned)
    if (originalRecord && originalRecord.status === BorrowingStatus.BORROWED && updatedRecord.status === BorrowingStatus.RETURNED) {
        const instrument = getInstrumentById(updatedRecord.instrumentId);
        if (instrument) {
            const quantityChange = updatedRecord.quantityBorrowed; // Quantity involved in this transaction

            const newInventoryItem = { ...instrument };
            newInventoryItem.quantityBorrowed -= quantityChange;
            if(newInventoryItem.quantityBorrowed < 0) newInventoryItem.quantityBorrowed = 0; // Sanity check

            switch (updatedRecord.remarks) {
                case ReturnRemark.COMPLETE:
                    newInventoryItem.quantityAvailable += quantityChange;
                    break;
                case ReturnRemark.BROKEN:
                    newInventoryItem.quantityBroken += quantityChange;
                    // Optionally, add notes to the item if not already detailed
                    newInventoryItem.notes = `${newInventoryItem.notes || ''} ${quantityChange} unit(s) returned broken by ${updatedRecord.borrowerName}.`.trim();
                    break;
                case ReturnRemark.INCOMPLETE:
                    // Assuming 'incomplete' means the borrowed quantity is now missing
                    newInventoryItem.quantityMissing += quantityChange;
                     newInventoryItem.notes = `${newInventoryItem.notes || ''} ${quantityChange} unit(s) returned incomplete/missing by ${updatedRecord.borrowerName}.`.trim();
                    break;
                default:
                    // If no remark or unhandled remark, assume it goes to available (or needs specific logic)
                    newInventoryItem.quantityAvailable += quantityChange; 
            }
            updateInventoryItem(newInventoryItem);
        }
    }
  }, [getInstrumentById, inventory, borrowers, updateInventoryItem]);


  return (
    <AppContext.Provider value={{ inventory, setInventory, borrowers, setBorrowers, addBorrowerRecord, updateBorrowerRecord, updateInventoryItem, getInstrumentById }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
