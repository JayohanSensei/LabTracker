
import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { Card } from '../common/Card';
import { Button } from '../common/Button';
import { LoginAttempt } from '../../types';

const DownloadIcon = () => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" /></svg>;

const StatusPill: React.FC<{ success: boolean }> = ({ success }) => {
  const bgColor = success ? 'bg-green-100' : 'bg-red-100';
  const textColor = success ? 'text-green-800/90' : 'text-red-800/90';
  const text = success ? 'Success' : 'Failed';
  return (
    <span className={`px-3 py-1 text-xs font-semibold rounded-full ${bgColor} ${textColor}`}>
      {text}
    </span>
  );
};

export const LoginHistoryPage: React.FC = () => {
  const { loginHistory } = useAuth();

  const downloadCSV = () => {
    if (loginHistory.length === 0) {
      alert("No login history to download.");
      return;
    }

    const headers = ['Timestamp', 'Email', 'Status'];
    const csvRows = [
      headers.join(','),
      ...loginHistory.map(attempt => 
        [
          `"${new Date(attempt.timestamp).toLocaleString()}"`,
          `"${attempt.email}"`,
          `"${attempt.success ? 'Success' : 'Failed'}"`
        ].join(',')
      )
    ];
    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'labtrack_login_history.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-center gap-4 p-4 bg-white shadow rounded-lg">
        <h1 className="text-2xl font-bold text-slate-800/70">User Login History</h1>
        <Button onClick={downloadCSV} variant="secondary" leftIcon={<DownloadIcon />} disabled={loginHistory.length === 0}>
          Download Report (CSV)
        </Button>
      </header>

      {loginHistory.length > 0 ? (
        <Card className="overflow-x-auto">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Timestamp</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Email</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500/70 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {loginHistory.map((attempt) => (
                <tr key={attempt.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{new Date(attempt.timestamp).toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700/70">{attempt.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StatusPill success={attempt.success} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      ) : (
        <Card>
          <div className="text-center py-10">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16 mx-auto text-slate-400 mb-4" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 6.75h7.5M8.25 12h7.5m-7.5 5.25h7.5M3.75 6.75h.007v.008H3.75V6.75zm.375 0a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0zM3.75 12h.007v.008H3.75V12zm.375 0a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0zm-.375 5.25h.007v.008H3.75v-.008zm.375 0a3.75 3.75 0 117.5 0 3.75 3.75 0 01-7.5 0z" />
            </svg>
            <p className="text-slate-600/70 text-xl">No login attempts recorded yet.</p>
            <p className="text-slate-500/70">Login activity will appear here as users attempt to log in.</p>
          </div>
        </Card>
      )}
    </div>
  );
};
